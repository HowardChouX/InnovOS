--
-- PostgreSQL database dump
--

\restrict DEIXdiG4EEuNr51SZc4XGNpeSArtZqSz0WN9GlbtNRIDoqaynDy5lqFIjf2wYm1

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analyses; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.analyses (
    id integer NOT NULL,
    task_id integer NOT NULL,
    center_node text DEFAULT '{}'::text NOT NULL,
    satellite_nodes text DEFAULT '[]'::text NOT NULL,
    edges text DEFAULT '[]'::text NOT NULL,
    principles text DEFAULT '[]'::text NOT NULL,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.analyses OWNER TO innovos;

--
-- Name: analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analyses_id_seq OWNER TO innovos;

--
-- Name: analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.analyses_id_seq OWNED BY public.analyses.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    provider_id text DEFAULT ''::text,
    key_name text NOT NULL,
    api_key text NOT NULL,
    api_base_url text DEFAULT 'https://api.deepseek.com'::text,
    api_model text DEFAULT 'deepseek-chat'::text,
    is_active integer DEFAULT 1,
    priority integer DEFAULT 0,
    max_rpm integer DEFAULT 60,
    current_rpm integer DEFAULT 0,
    last_reset_at text,
    last_used_at text,
    request_count integer DEFAULT 0,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.api_keys OWNER TO innovos;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO innovos;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    user_id integer,
    username text DEFAULT ''::text NOT NULL,
    action text NOT NULL,
    resource_type text DEFAULT ''::text NOT NULL,
    resource_id text DEFAULT ''::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL,
    ip_address text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.audit_log OWNER TO innovos;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO innovos;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: evaluations; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.evaluations (
    id integer NOT NULL,
    solution_id integer NOT NULL,
    user_id integer NOT NULL,
    dimension text DEFAULT 'comprehensive'::text NOT NULL,
    score real DEFAULT 0,
    details text DEFAULT '{}'::text,
    status text DEFAULT 'completed'::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    root_cause_cut integer DEFAULT 0,
    original_contradiction_resolved integer DEFAULT 0,
    new_contradictions text DEFAULT '[]'::text,
    function_deficits_filled text DEFAULT '[]'::text,
    new_harmful_interactions text DEFAULT '[]'::text,
    ifr_distance text DEFAULT 'far'::text,
    ifr_gap_description text DEFAULT ''::text,
    ifr_parameters_achieved text DEFAULT '[]'::text,
    overall_verdict text DEFAULT 'failed'::text,
    evolution_alignment real DEFAULT 0,
    aligned_laws text DEFAULT '[]'::text,
    misaligned_laws text DEFAULT '[]'::text,
    maturity text DEFAULT '概念阶段'::text,
    confidence real,
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.evaluations OWNER TO innovos;

--
-- Name: evaluations_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.evaluations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.evaluations_id_seq OWNER TO innovos;

--
-- Name: evaluations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.evaluations_id_seq OWNED BY public.evaluations.id;


--
-- Name: feedbacks; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.feedbacks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    solution_id integer NOT NULL,
    rating integer NOT NULL,
    feedback_type text DEFAULT 'general'::text,
    comments text DEFAULT ''::text,
    is_applied integer DEFAULT 0,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    CONSTRAINT feedbacks_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.feedbacks OWNER TO innovos;

--
-- Name: feedbacks_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.feedbacks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.feedbacks_id_seq OWNER TO innovos;

--
-- Name: feedbacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.feedbacks_id_seq OWNED BY public.feedbacks.id;


--
-- Name: knowledge_bases; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_bases (
    id text NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    group_id text,
    dimensions integer,
    embedding_model_id text,
    status text DEFAULT 'completed'::text,
    error text,
    rerank_model_id text,
    file_processor_id text,
    chunk_size integer DEFAULT 1024,
    chunk_overlap integer DEFAULT 200,
    threshold real,
    document_count integer,
    search_mode text DEFAULT 'hybrid'::text,
    hybrid_alpha real,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_bases OWNER TO innovos;

--
-- Name: knowledge_docs; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_docs (
    id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    category text DEFAULT '未分类'::text,
    tags text DEFAULT '[]'::text,
    source text DEFAULT ''::text,
    doc_type text DEFAULT 'text'::text,
    user_id integer NOT NULL,
    base_id integer DEFAULT 0,
    is_active integer DEFAULT 1,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_docs OWNER TO innovos;

--
-- Name: knowledge_docs_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.knowledge_docs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_docs_id_seq OWNER TO innovos;

--
-- Name: knowledge_docs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.knowledge_docs_id_seq OWNED BY public.knowledge_docs.id;


--
-- Name: knowledge_groups; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_groups (
    id text NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_groups OWNER TO innovos;

--
-- Name: knowledge_items; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_items (
    id text NOT NULL,
    base_id text NOT NULL,
    group_id text,
    type text NOT NULL,
    data text DEFAULT '{}'::text NOT NULL,
    status text DEFAULT 'idle'::text NOT NULL,
    error text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_items OWNER TO innovos;

--
-- Name: knowledge_jobs; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_jobs (
    id text NOT NULL,
    job_type text NOT NULL,
    queue text NOT NULL,
    input_data text DEFAULT '{}'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempt integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    timeout_ms integer DEFAULT 600000 NOT NULL,
    parent_job_id text,
    idempotency_key text,
    error text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_jobs OWNER TO innovos;

--
-- Name: knowledge_vectors; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_vectors (
    id integer NOT NULL,
    user_id integer NOT NULL,
    base_id text NOT NULL,
    item_id text NOT NULL,
    chunk_index integer DEFAULT 0 NOT NULL,
    text text NOT NULL,
    embedding public.vector(4096),
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_vectors OWNER TO innovos;

--
-- Name: knowledge_vectors_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.knowledge_vectors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_vectors_id_seq OWNER TO innovos;

--
-- Name: knowledge_vectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.knowledge_vectors_id_seq OWNED BY public.knowledge_vectors.id;


--
-- Name: model_providers; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.model_providers (
    id integer NOT NULL,
    provider_id text NOT NULL,
    name text NOT NULL,
    protocol text DEFAULT 'openai'::text,
    api_host text NOT NULL,
    api_model text DEFAULT ''::text,
    models text DEFAULT '[]'::text,
    max_rpm integer DEFAULT 60,
    current_rpm integer DEFAULT 0,
    request_count integer DEFAULT 0,
    is_enabled integer DEFAULT 1,
    last_used_at text,
    last_reset_at text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.model_providers OWNER TO innovos;

--
-- Name: model_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.model_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_providers_id_seq OWNER TO innovos;

--
-- Name: model_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.model_providers_id_seq OWNED BY public.model_providers.id;


--
-- Name: models; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.models (
    id integer NOT NULL,
    provider_id text NOT NULL,
    model_id text NOT NULL,
    name text DEFAULT ''::text,
    capabilities text DEFAULT '[]'::text,
    endpoint_types text DEFAULT '[]'::text,
    context_window integer DEFAULT 0,
    max_output_tokens integer DEFAULT 0,
    max_input_tokens integer DEFAULT 0,
    model_group text DEFAULT ''::text,
    is_enabled integer DEFAULT 1,
    metadata text DEFAULT '{}'::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.models OWNER TO innovos;

--
-- Name: models_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.models_id_seq OWNER TO innovos;

--
-- Name: models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.models_id_seq OWNED BY public.models.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    type text DEFAULT 'system'::text,
    is_read integer DEFAULT 0,
    is_recalled integer DEFAULT 0,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.notifications OWNER TO innovos;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO innovos;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: patents; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.patents (
    id integer NOT NULL,
    title text NOT NULL,
    abstract text DEFAULT ''::text,
    applicants text DEFAULT '[]'::text,
    inventors text DEFAULT '[]'::text,
    filing_date text DEFAULT ''::text,
    publication_date text DEFAULT ''::text,
    patent_number text DEFAULT ''::text,
    ipc_codes text DEFAULT '[]'::text,
    relevance_score integer DEFAULT 0,
    publication_number text DEFAULT ''::text,
    claims text DEFAULT ''::text,
    description text DEFAULT ''::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.patents OWNER TO innovos;

--
-- Name: patents_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.patents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patents_id_seq OWNER TO innovos;

--
-- Name: patents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.patents_id_seq OWNED BY public.patents.id;


--
-- Name: problem_modelings; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.problem_modelings (
    id integer NOT NULL,
    task_id integer NOT NULL,
    problem_elements text DEFAULT '{}'::text NOT NULL,
    conflicts text DEFAULT '[]'::text NOT NULL,
    recommended_principles text DEFAULT '[]'::text NOT NULL,
    innovation_directions text DEFAULT '[]'::text NOT NULL,
    model_structure text DEFAULT '{}'::text NOT NULL,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.problem_modelings OWNER TO innovos;

--
-- Name: problem_modelings_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.problem_modelings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.problem_modelings_id_seq OWNER TO innovos;

--
-- Name: problem_modelings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.problem_modelings_id_seq OWNED BY public.problem_modelings.id;


--
-- Name: solutions; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.solutions (
    id integer NOT NULL,
    task_id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    principles text DEFAULT '[]'::text,
    confidence_score integer DEFAULT 0,
    patent_references text DEFAULT '[]'::text,
    rating integer DEFAULT 0,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.solutions OWNER TO innovos;

--
-- Name: solutions_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.solutions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.solutions_id_seq OWNER TO innovos;

--
-- Name: solutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.solutions_id_seq OWNED BY public.solutions.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key text NOT NULL,
    value text DEFAULT '{}'::text NOT NULL,
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.system_settings OWNER TO innovos;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO innovos;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    tags text DEFAULT '[]'::text,
    status text DEFAULT 'pending'::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.tasks OWNER TO innovos;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO innovos;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'user'::text,
    email text DEFAULT ''::text,
    is_active integer DEFAULT 1,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    token_version integer DEFAULT 0,
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.users OWNER TO innovos;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO innovos;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    task_id integer NOT NULL,
    status text DEFAULT 'running'::text,
    steps text DEFAULT '[]'::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.workflows OWNER TO innovos;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO innovos;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: analyses id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.analyses ALTER COLUMN id SET DEFAULT nextval('public.analyses_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: evaluations id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.evaluations ALTER COLUMN id SET DEFAULT nextval('public.evaluations_id_seq'::regclass);


--
-- Name: feedbacks id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.feedbacks ALTER COLUMN id SET DEFAULT nextval('public.feedbacks_id_seq'::regclass);


--
-- Name: knowledge_docs id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_docs ALTER COLUMN id SET DEFAULT nextval('public.knowledge_docs_id_seq'::regclass);


--
-- Name: knowledge_vectors id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors ALTER COLUMN id SET DEFAULT nextval('public.knowledge_vectors_id_seq'::regclass);


--
-- Name: model_providers id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.model_providers ALTER COLUMN id SET DEFAULT nextval('public.model_providers_id_seq'::regclass);


--
-- Name: models id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.models ALTER COLUMN id SET DEFAULT nextval('public.models_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: patents id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.patents ALTER COLUMN id SET DEFAULT nextval('public.patents_id_seq'::regclass);


--
-- Name: problem_modelings id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.problem_modelings ALTER COLUMN id SET DEFAULT nextval('public.problem_modelings_id_seq'::regclass);


--
-- Name: solutions id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.solutions ALTER COLUMN id SET DEFAULT nextval('public.solutions_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: analyses; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.analyses (id, task_id, center_node, satellite_nodes, edges, principles, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.api_keys (id, provider_id, key_name, api_key, api_base_url, api_model, is_active, priority, max_rpm, current_rpm, last_reset_at, last_used_at, request_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.audit_log (id, user_id, username, action, resource_type, resource_id, detail, ip_address, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: evaluations; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.evaluations (id, solution_id, user_id, dimension, score, details, status, created_at, root_cause_cut, original_contradiction_resolved, new_contradictions, function_deficits_filled, new_harmful_interactions, ifr_distance, ifr_gap_description, ifr_parameters_achieved, overall_verdict, evolution_alignment, aligned_laws, misaligned_laws, maturity, confidence, updated_at) FROM stdin;
\.


--
-- Data for Name: feedbacks; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.feedbacks (id, user_id, solution_id, rating, feedback_type, comments, is_applied, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_bases; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_bases (id, user_id, name, group_id, dimensions, embedding_model_id, status, error, rerank_model_id, file_processor_id, chunk_size, chunk_overlap, threshold, document_count, search_mode, hybrid_alpha, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_docs; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_docs (id, title, content, category, tags, source, doc_type, user_id, base_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_groups; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_groups (id, user_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_items; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_items (id, base_id, group_id, type, data, status, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_jobs; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_jobs (id, job_type, queue, input_data, status, attempt, max_attempts, timeout_ms, parent_job_id, idempotency_key, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_vectors; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_vectors (id, user_id, base_id, item_id, chunk_index, text, embedding, created_at) FROM stdin;
\.


--
-- Data for Name: model_providers; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.model_providers (id, provider_id, name, protocol, api_host, api_model, models, max_rpm, current_rpm, request_count, is_enabled, last_used_at, last_reset_at, created_at, updated_at) FROM stdin;
1	deepseek	DeepSeek	openai	https://api.deepseek.com		[]	60	0	0	1	\N	\N	2026-07-03 23:52:00	2026-07-03 23:52:00
2	silicon	SiliconFlow	openai	https://api.siliconflow.cn		[]	60	0	0	1	\N	\N	2026-07-03 23:52:00	2026-07-03 23:52:00
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.models (id, provider_id, model_id, name, capabilities, endpoint_types, context_window, max_output_tokens, max_input_tokens, model_group, is_enabled, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.notifications (id, user_id, title, content, type, is_read, is_recalled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: patents; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.patents (id, title, abstract, applicants, inventors, filing_date, publication_date, patent_number, ipc_codes, relevance_score, publication_number, claims, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: problem_modelings; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.problem_modelings (id, task_id, problem_elements, conflicts, recommended_principles, innovation_directions, model_structure, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: solutions; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.solutions (id, task_id, title, description, principles, confidence_score, patent_references, rating, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.system_settings (id, key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.tasks (id, user_id, title, description, tags, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.users (id, username, password_hash, role, email, is_active, created_at, token_version, updated_at) FROM stdin;
0	admin@innovos.com		admin		1	2026-07-03 23:52:00	0	2026-07-03 23:52:00
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.workflows (id, task_id, status, steps, created_at, updated_at) FROM stdin;
\.


--
-- Name: analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.analyses_id_seq', 1, false);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: evaluations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.evaluations_id_seq', 1, false);


--
-- Name: feedbacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.feedbacks_id_seq', 1, false);


--
-- Name: knowledge_docs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.knowledge_docs_id_seq', 1, false);


--
-- Name: knowledge_vectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.knowledge_vectors_id_seq', 1, false);


--
-- Name: model_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.model_providers_id_seq', 2, true);


--
-- Name: models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.models_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: patents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.patents_id_seq', 1, false);


--
-- Name: problem_modelings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.problem_modelings_id_seq', 1, false);


--
-- Name: solutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.solutions_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1, false);


--
-- Name: analyses analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_pkey PRIMARY KEY (id);


--
-- Name: analyses analyses_task_id_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_task_id_key UNIQUE (task_id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: evaluations evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_pkey PRIMARY KEY (id);


--
-- Name: feedbacks feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_pkey PRIMARY KEY (id);


--
-- Name: knowledge_bases knowledge_bases_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_bases
    ADD CONSTRAINT knowledge_bases_pkey PRIMARY KEY (id);


--
-- Name: knowledge_docs knowledge_docs_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_docs
    ADD CONSTRAINT knowledge_docs_pkey PRIMARY KEY (id);


--
-- Name: knowledge_groups knowledge_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_groups
    ADD CONSTRAINT knowledge_groups_pkey PRIMARY KEY (id);


--
-- Name: knowledge_items knowledge_items_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_items
    ADD CONSTRAINT knowledge_items_pkey PRIMARY KEY (id);


--
-- Name: knowledge_jobs knowledge_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_jobs
    ADD CONSTRAINT knowledge_jobs_pkey PRIMARY KEY (id);


--
-- Name: knowledge_vectors knowledge_vectors_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors
    ADD CONSTRAINT knowledge_vectors_pkey PRIMARY KEY (id);


--
-- Name: model_providers model_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.model_providers
    ADD CONSTRAINT model_providers_pkey PRIMARY KEY (id);


--
-- Name: model_providers model_providers_provider_id_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.model_providers
    ADD CONSTRAINT model_providers_provider_id_key UNIQUE (provider_id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: patents patents_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.patents
    ADD CONSTRAINT patents_pkey PRIMARY KEY (id);


--
-- Name: problem_modelings problem_modelings_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.problem_modelings
    ADD CONSTRAINT problem_modelings_pkey PRIMARY KEY (id);


--
-- Name: problem_modelings problem_modelings_task_id_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.problem_modelings
    ADD CONSTRAINT problem_modelings_task_id_key UNIQUE (task_id);


--
-- Name: solutions solutions_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.solutions
    ADD CONSTRAINT solutions_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_key_key UNIQUE (key);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_task_id_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_task_id_key UNIQUE (task_id);


--
-- Name: idx_analyses_task_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_analyses_task_id ON public.analyses USING btree (task_id);


--
-- Name: idx_api_keys_is_active; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_api_keys_is_active ON public.api_keys USING btree (is_active);


--
-- Name: idx_audit_log_action; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_log_created; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_audit_log_created ON public.audit_log USING btree (created_at);


--
-- Name: idx_audit_log_user; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_audit_log_user ON public.audit_log USING btree (user_id);


--
-- Name: idx_evaluations_solution_user; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_evaluations_solution_user ON public.evaluations USING btree (solution_id, user_id);


--
-- Name: idx_feedbacks_solution_user; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_feedbacks_solution_user ON public.feedbacks USING btree (solution_id, user_id);


--
-- Name: idx_knowledge_bases_user_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_bases_user_id ON public.knowledge_bases USING btree (user_id);


--
-- Name: idx_knowledge_docs_user_active; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_docs_user_active ON public.knowledge_docs USING btree (user_id, is_active);


--
-- Name: idx_knowledge_groups_user_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_groups_user_id ON public.knowledge_groups USING btree (user_id);


--
-- Name: idx_knowledge_items_base_group_created; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_items_base_group_created ON public.knowledge_items USING btree (base_id, group_id, created_at);


--
-- Name: idx_knowledge_items_base_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_items_base_id ON public.knowledge_items USING btree (base_id);


--
-- Name: idx_knowledge_items_base_type_created; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_items_base_type_created ON public.knowledge_items USING btree (base_id, type, created_at);


--
-- Name: idx_knowledge_items_status; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_items_status ON public.knowledge_items USING btree (status);


--
-- Name: idx_knowledge_jobs_idempotency; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_jobs_idempotency ON public.knowledge_jobs USING btree (idempotency_key);


--
-- Name: idx_knowledge_jobs_idempotency_unique; Type: INDEX; Schema: public; Owner: innovos
--

CREATE UNIQUE INDEX idx_knowledge_jobs_idempotency_unique ON public.knowledge_jobs USING btree (idempotency_key) WHERE ((idempotency_key IS NOT NULL) AND (idempotency_key <> ''::text));


--
-- Name: idx_knowledge_jobs_queue_status; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_jobs_queue_status ON public.knowledge_jobs USING btree (queue, status);


--
-- Name: idx_knowledge_vectors_base_item; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_vectors_base_item ON public.knowledge_vectors USING btree (base_id, item_id);


--
-- Name: idx_knowledge_vectors_item_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_vectors_item_id ON public.knowledge_vectors USING btree (item_id);


--
-- Name: idx_knowledge_vectors_user_base; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_vectors_user_base ON public.knowledge_vectors USING btree (user_id, base_id);


--
-- Name: idx_models_provider_model; Type: INDEX; Schema: public; Owner: innovos
--

CREATE UNIQUE INDEX idx_models_provider_model ON public.models USING btree (provider_id, model_id);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_patents_patent_number; Type: INDEX; Schema: public; Owner: innovos
--

CREATE UNIQUE INDEX idx_patents_patent_number ON public.patents USING btree (patent_number) WHERE (patent_number <> ''::text);


--
-- Name: idx_patents_relevance_score; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_patents_relevance_score ON public.patents USING btree (relevance_score DESC);


--
-- Name: idx_problem_modelings_task_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_problem_modelings_task_id ON public.problem_modelings USING btree (task_id);


--
-- Name: idx_solutions_task_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_solutions_task_id ON public.solutions USING btree (task_id);


--
-- Name: idx_tasks_user_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_tasks_user_id ON public.tasks USING btree (user_id);


--
-- Name: idx_workflows_task_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_workflows_task_id ON public.workflows USING btree (task_id);


--
-- Name: analyses analyses_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: evaluations evaluations_solution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_solution_id_fkey FOREIGN KEY (solution_id) REFERENCES public.solutions(id) ON DELETE CASCADE;


--
-- Name: evaluations evaluations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: feedbacks feedbacks_solution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_solution_id_fkey FOREIGN KEY (solution_id) REFERENCES public.solutions(id) ON DELETE CASCADE;


--
-- Name: feedbacks feedbacks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: knowledge_vectors fk_kv_base; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors
    ADD CONSTRAINT fk_kv_base FOREIGN KEY (base_id) REFERENCES public.knowledge_bases(id) ON DELETE CASCADE;


--
-- Name: knowledge_vectors fk_kv_item; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors
    ADD CONSTRAINT fk_kv_item FOREIGN KEY (item_id) REFERENCES public.knowledge_items(id) ON DELETE CASCADE;


--
-- Name: knowledge_bases knowledge_bases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_bases
    ADD CONSTRAINT knowledge_bases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: knowledge_docs knowledge_docs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_docs
    ADD CONSTRAINT knowledge_docs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: knowledge_groups knowledge_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_groups
    ADD CONSTRAINT knowledge_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: knowledge_items knowledge_items_base_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_items
    ADD CONSTRAINT knowledge_items_base_id_fkey FOREIGN KEY (base_id) REFERENCES public.knowledge_bases(id) ON DELETE CASCADE;


--
-- Name: knowledge_vectors knowledge_vectors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors
    ADD CONSTRAINT knowledge_vectors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: problem_modelings problem_modelings_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.problem_modelings
    ADD CONSTRAINT problem_modelings_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: solutions solutions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.solutions
    ADD CONSTRAINT solutions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: workflows workflows_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict DEIXdiG4EEuNr51SZc4XGNpeSArtZqSz0WN9GlbtNRIDoqaynDy5lqFIjf2wYm1

