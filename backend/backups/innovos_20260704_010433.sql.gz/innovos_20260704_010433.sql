--
-- PostgreSQL database dump
--

\restrict cZprGSR0dcISHqZoyAhcgn4eN0mqXmgRM5MaznTaR2Z5Vz1U951ZlPDFY2GMHUT

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analyses; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.analyses (
    id integer NOT NULL,
    task_id integer NOT NULL,
    center_node text DEFAULT '{}'::text NOT NULL,
    satellite_nodes text DEFAULT '[]'::text NOT NULL,
    edges text DEFAULT '[]'::text NOT NULL,
    principles text DEFAULT '[]'::text NOT NULL,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.analyses OWNER TO innovos;

--
-- Name: analyses_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.analyses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.analyses_id_seq OWNER TO innovos;

--
-- Name: analyses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.analyses_id_seq OWNED BY public.analyses.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    provider_id text DEFAULT ''::text,
    key_name text NOT NULL,
    api_key text NOT NULL,
    api_base_url text DEFAULT 'https://api.deepseek.com'::text,
    api_model text DEFAULT 'deepseek-chat'::text,
    is_active integer DEFAULT 1,
    priority integer DEFAULT 0,
    max_rpm integer DEFAULT 60,
    current_rpm integer DEFAULT 0,
    last_reset_at text,
    last_used_at text,
    request_count integer DEFAULT 0,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.api_keys OWNER TO innovos;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO innovos;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    user_id integer,
    username text DEFAULT ''::text NOT NULL,
    action text NOT NULL,
    resource_type text DEFAULT ''::text NOT NULL,
    resource_id text DEFAULT ''::text NOT NULL,
    detail text DEFAULT '{}'::text NOT NULL,
    ip_address text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.audit_log OWNER TO innovos;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO innovos;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: evaluations; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.evaluations (
    id integer NOT NULL,
    solution_id integer NOT NULL,
    user_id integer NOT NULL,
    dimension text DEFAULT 'comprehensive'::text NOT NULL,
    score real DEFAULT 0,
    details text DEFAULT '{}'::text,
    status text DEFAULT 'completed'::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    root_cause_cut integer DEFAULT 0,
    original_contradiction_resolved integer DEFAULT 0,
    new_contradictions text DEFAULT '[]'::text,
    function_deficits_filled text DEFAULT '[]'::text,
    new_harmful_interactions text DEFAULT '[]'::text,
    ifr_distance text DEFAULT 'far'::text,
    ifr_gap_description text DEFAULT ''::text,
    ifr_parameters_achieved text DEFAULT '[]'::text,
    overall_verdict text DEFAULT 'failed'::text,
    evolution_alignment real DEFAULT 0,
    aligned_laws text DEFAULT '[]'::text,
    misaligned_laws text DEFAULT '[]'::text,
    maturity text DEFAULT '概念阶段'::text,
    confidence real,
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.evaluations OWNER TO innovos;

--
-- Name: evaluations_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.evaluations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.evaluations_id_seq OWNER TO innovos;

--
-- Name: evaluations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.evaluations_id_seq OWNED BY public.evaluations.id;


--
-- Name: feedbacks; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.feedbacks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    solution_id integer NOT NULL,
    rating integer NOT NULL,
    feedback_type text DEFAULT 'general'::text,
    comments text DEFAULT ''::text,
    is_applied integer DEFAULT 0,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    CONSTRAINT feedbacks_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.feedbacks OWNER TO innovos;

--
-- Name: feedbacks_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.feedbacks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.feedbacks_id_seq OWNER TO innovos;

--
-- Name: feedbacks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.feedbacks_id_seq OWNED BY public.feedbacks.id;


--
-- Name: knowledge_bases; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_bases (
    id text NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    group_id text,
    dimensions integer,
    embedding_model_id text,
    status text DEFAULT 'completed'::text,
    error text,
    rerank_model_id text,
    file_processor_id text,
    chunk_size integer DEFAULT 1024,
    chunk_overlap integer DEFAULT 200,
    threshold real,
    document_count integer,
    search_mode text DEFAULT 'hybrid'::text,
    hybrid_alpha real,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_bases OWNER TO innovos;

--
-- Name: knowledge_docs; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_docs (
    id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    category text DEFAULT '未分类'::text,
    tags text DEFAULT '[]'::text,
    source text DEFAULT ''::text,
    doc_type text DEFAULT 'text'::text,
    user_id integer NOT NULL,
    base_id integer DEFAULT 0,
    is_active integer DEFAULT 1,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_docs OWNER TO innovos;

--
-- Name: knowledge_docs_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.knowledge_docs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_docs_id_seq OWNER TO innovos;

--
-- Name: knowledge_docs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.knowledge_docs_id_seq OWNED BY public.knowledge_docs.id;


--
-- Name: knowledge_groups; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_groups (
    id text NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_groups OWNER TO innovos;

--
-- Name: knowledge_items; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_items (
    id text NOT NULL,
    base_id text NOT NULL,
    group_id text,
    type text NOT NULL,
    data text DEFAULT '{}'::text NOT NULL,
    status text DEFAULT 'idle'::text NOT NULL,
    error text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_items OWNER TO innovos;

--
-- Name: knowledge_jobs; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_jobs (
    id text NOT NULL,
    job_type text NOT NULL,
    queue text NOT NULL,
    input_data text DEFAULT '{}'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempt integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 3 NOT NULL,
    timeout_ms integer DEFAULT 600000 NOT NULL,
    parent_job_id text,
    idempotency_key text,
    error text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_jobs OWNER TO innovos;

--
-- Name: knowledge_vectors; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.knowledge_vectors (
    id integer NOT NULL,
    user_id integer NOT NULL,
    base_id text NOT NULL,
    item_id text NOT NULL,
    chunk_index integer DEFAULT 0 NOT NULL,
    text text NOT NULL,
    embedding public.vector(4096),
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.knowledge_vectors OWNER TO innovos;

--
-- Name: knowledge_vectors_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.knowledge_vectors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_vectors_id_seq OWNER TO innovos;

--
-- Name: knowledge_vectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.knowledge_vectors_id_seq OWNED BY public.knowledge_vectors.id;


--
-- Name: model_providers; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.model_providers (
    id integer NOT NULL,
    provider_id text NOT NULL,
    name text NOT NULL,
    protocol text DEFAULT 'openai'::text,
    api_host text NOT NULL,
    api_model text DEFAULT ''::text,
    models text DEFAULT '[]'::text,
    max_rpm integer DEFAULT 60,
    current_rpm integer DEFAULT 0,
    request_count integer DEFAULT 0,
    is_enabled integer DEFAULT 1,
    last_used_at text,
    last_reset_at text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.model_providers OWNER TO innovos;

--
-- Name: model_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.model_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_providers_id_seq OWNER TO innovos;

--
-- Name: model_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.model_providers_id_seq OWNED BY public.model_providers.id;


--
-- Name: models; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.models (
    id integer NOT NULL,
    provider_id text NOT NULL,
    model_id text NOT NULL,
    name text DEFAULT ''::text,
    capabilities text DEFAULT '[]'::text,
    endpoint_types text DEFAULT '[]'::text,
    context_window integer DEFAULT 0,
    max_output_tokens integer DEFAULT 0,
    max_input_tokens integer DEFAULT 0,
    model_group text DEFAULT ''::text,
    is_enabled integer DEFAULT 1,
    metadata text DEFAULT '{}'::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.models OWNER TO innovos;

--
-- Name: models_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.models_id_seq OWNER TO innovos;

--
-- Name: models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.models_id_seq OWNED BY public.models.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    type text DEFAULT 'system'::text,
    is_read integer DEFAULT 0,
    is_recalled integer DEFAULT 0,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.notifications OWNER TO innovos;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO innovos;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: patent_vectors; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.patent_vectors (
    patent_id integer NOT NULL,
    embedding public.halfvec(4000),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.patent_vectors OWNER TO innovos;

--
-- Name: patents; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.patents (
    id integer NOT NULL,
    title text NOT NULL,
    abstract text DEFAULT ''::text,
    applicants text DEFAULT '[]'::text,
    inventors text DEFAULT '[]'::text,
    filing_date text DEFAULT ''::text,
    publication_date text DEFAULT ''::text,
    patent_number text DEFAULT ''::text,
    ipc_codes text DEFAULT '[]'::text,
    relevance_score integer DEFAULT 0,
    publication_number text DEFAULT ''::text,
    claims text DEFAULT ''::text,
    description text DEFAULT ''::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.patents OWNER TO innovos;

--
-- Name: patents_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.patents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.patents_id_seq OWNER TO innovos;

--
-- Name: patents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.patents_id_seq OWNED BY public.patents.id;


--
-- Name: problem_modelings; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.problem_modelings (
    id integer NOT NULL,
    task_id integer NOT NULL,
    problem_elements text DEFAULT '{}'::text NOT NULL,
    conflicts text DEFAULT '[]'::text NOT NULL,
    recommended_principles text DEFAULT '[]'::text NOT NULL,
    innovation_directions text DEFAULT '[]'::text NOT NULL,
    model_structure text DEFAULT '{}'::text NOT NULL,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.problem_modelings OWNER TO innovos;

--
-- Name: problem_modelings_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.problem_modelings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.problem_modelings_id_seq OWNER TO innovos;

--
-- Name: problem_modelings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.problem_modelings_id_seq OWNED BY public.problem_modelings.id;


--
-- Name: solutions; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.solutions (
    id integer NOT NULL,
    task_id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    principles text DEFAULT '[]'::text,
    confidence_score integer DEFAULT 0,
    patent_references text DEFAULT '[]'::text,
    rating integer DEFAULT 0,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.solutions OWNER TO innovos;

--
-- Name: solutions_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.solutions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.solutions_id_seq OWNER TO innovos;

--
-- Name: solutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.solutions_id_seq OWNED BY public.solutions.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    key text NOT NULL,
    value text DEFAULT '{}'::text NOT NULL,
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.system_settings OWNER TO innovos;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO innovos;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    tags text DEFAULT '[]'::text,
    status text DEFAULT 'pending'::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.tasks OWNER TO innovos;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO innovos;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'user'::text,
    email text DEFAULT ''::text,
    is_active integer DEFAULT 1,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    token_version integer DEFAULT 0,
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.users OWNER TO innovos;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO innovos;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: innovos
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    task_id integer NOT NULL,
    status text DEFAULT 'running'::text,
    steps text DEFAULT '[]'::text,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text),
    updated_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text)
);


ALTER TABLE public.workflows OWNER TO innovos;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: innovos
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO innovos;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: innovos
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: analyses id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.analyses ALTER COLUMN id SET DEFAULT nextval('public.analyses_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: evaluations id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.evaluations ALTER COLUMN id SET DEFAULT nextval('public.evaluations_id_seq'::regclass);


--
-- Name: feedbacks id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.feedbacks ALTER COLUMN id SET DEFAULT nextval('public.feedbacks_id_seq'::regclass);


--
-- Name: knowledge_docs id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_docs ALTER COLUMN id SET DEFAULT nextval('public.knowledge_docs_id_seq'::regclass);


--
-- Name: knowledge_vectors id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors ALTER COLUMN id SET DEFAULT nextval('public.knowledge_vectors_id_seq'::regclass);


--
-- Name: model_providers id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.model_providers ALTER COLUMN id SET DEFAULT nextval('public.model_providers_id_seq'::regclass);


--
-- Name: models id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.models ALTER COLUMN id SET DEFAULT nextval('public.models_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: patents id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.patents ALTER COLUMN id SET DEFAULT nextval('public.patents_id_seq'::regclass);


--
-- Name: problem_modelings id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.problem_modelings ALTER COLUMN id SET DEFAULT nextval('public.problem_modelings_id_seq'::regclass);


--
-- Name: solutions id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.solutions ALTER COLUMN id SET DEFAULT nextval('public.solutions_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: analyses; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.analyses (id, task_id, center_node, satellite_nodes, edges, principles, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.api_keys (id, provider_id, key_name, api_key, api_base_url, api_model, is_active, priority, max_rpm, current_rpm, last_reset_at, last_used_at, request_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.audit_log (id, user_id, username, action, resource_type, resource_id, detail, ip_address, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: evaluations; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.evaluations (id, solution_id, user_id, dimension, score, details, status, created_at, root_cause_cut, original_contradiction_resolved, new_contradictions, function_deficits_filled, new_harmful_interactions, ifr_distance, ifr_gap_description, ifr_parameters_achieved, overall_verdict, evolution_alignment, aligned_laws, misaligned_laws, maturity, confidence, updated_at) FROM stdin;
1	1	0	可行性	90	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
2	1	0	创新性	85	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
3	1	0	成本	75	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
4	1	0	转化价值	88	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
5	2	0	可行性	82	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
6	2	0	创新性	90	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
7	2	0	成本	70	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
8	2	0	转化价值	85	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
9	3	0	可行性	78	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
10	3	0	创新性	88	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
11	3	0	成本	65	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
12	3	0	转化价值	80	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
13	4	0	可行性	85	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
14	4	0	创新性	80	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
15	4	0	成本	78	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
16	4	0	转化价值	82	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
17	5	0	可行性	88	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
18	5	0	创新性	82	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
19	5	0	成本	72	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
20	5	0	转化价值	90	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
21	6	0	可行性	80	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
22	6	0	创新性	88	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
23	6	0	成本	70	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
24	6	0	转化价值	85	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
25	7	0	可行性	83	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
26	7	0	创新性	86	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
27	7	0	成本	75	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
28	7	0	转化价值	88	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
29	8	0	可行性	85	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
30	8	0	创新性	78	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
31	8	0	成本	80	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
32	8	0	转化价值	82	{}	completed	2026-07-04 00:59:19	0	0	[]	[]	[]	far		[]	failed	0	[]	[]	概念阶段	\N	2026-07-04 00:59:19
\.


--
-- Data for Name: feedbacks; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.feedbacks (id, user_id, solution_id, rating, feedback_type, comments, is_applied, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_bases; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_bases (id, user_id, name, group_id, dimensions, embedding_model_id, status, error, rerank_model_id, file_processor_id, chunk_size, chunk_overlap, threshold, document_count, search_mode, hybrid_alpha, created_at, updated_at) FROM stdin;
mock-kb-phone-heat	0	手机发热技术笔记库	\N	\N	\N	completed	\N	\N	\N	1024	200	\N	\N	hybrid	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
\.


--
-- Data for Name: knowledge_docs; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_docs (id, title, content, category, tags, source, doc_type, user_id, base_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_groups; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_groups (id, user_id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_items; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_items (id, base_id, group_id, type, data, status, error, created_at, updated_at) FROM stdin;
mock-note-001	mock-kb-phone-heat	\N	note	{"title": "石墨烯散热膜在手机中的应用", "content": "石墨烯散热膜利用石墨烯超高面内导热系数（~5000 W/mK）实现快速均温。实际应用中，厚度通常为25-50μm，需配合导热凝胶贴合在芯片表面。测试表明，石墨烯膜可使手机热点温度降低3-5°C。关键工艺挑战在于石墨烯薄膜的大面积转移和无缺陷贴合。", "tags": ["石墨烯", "散热膜", "导热"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-002	mock-kb-phone-heat	\N	note	{"title": "VC均热板工作原理与设计要点", "content": "VC均热板利用真空腔体内工质（通常为纯水）的相变循环实现高效散热：蒸发段吸热汽化 → 蒸汽流向冷凝段 → 冷凝放热 → 凝液经毛细吸液芯回流。散热功率可达石墨片的3-5倍。设计要点：毛细吸液芯的毛细力需大于工质回流阻力；充液率通常为20-30%；超薄VC厚度可做到0.3mm。", "tags": ["VC均热板", "相变散热", "毛细结构"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-003	mock-kb-phone-heat	\N	note	{"title": "手机发热问题根因分析", "content": "手机发热主要热源：1) SoC芯片（CPU/GPU高负载，游戏/视频场景）；2) 快充充电（大电流产生焦耳热）；3) 电池内阻发热（老化电池内阻增大）；4) 射频PA（5G高功率发射）；5) 屏幕背光（高亮度持续工作）。发热会导致降频卡顿、电池老化加速、用户烫手感不适。核心矛盾：性能需求 vs 散热空间受限。", "tags": ["发热根因", "热源分析", "性能矛盾"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-004	mock-kb-phone-heat	\N	note	{"title": "相变储热材料在手机散热中的应用", "content": "相变材料（PCM）通过固-液相变吸收潜热，延缓温度上升。手机中常用石蜡基PCM，相变温度40-45°C，潜热约200J/g。优势：无需能耗、无噪音、可填充于狭小空间。局限：储热容量有限（仅延缓非消除）、导热系数低（需添加石墨/金属填料增强）、封装需防泄漏。微胶囊化可提升可加工性。", "tags": ["相变材料", "储热", "石蜡"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-005	mock-kb-phone-heat	\N	note	{"title": "手机热设计功率（TDP）评估方法", "content": "手机热设计需评估各场景TDP：待机0.5-1W、日常使用2-4W、游戏5-8W、快充充电6-10W。散热能力需覆盖最恶劣场景。评估方法：1) 红外热像仪测绘温度分布；2) 多点热电偶采集关键点温度；3) CFD仿真模拟热流路径。关键指标：热点温度（≤45°C触感舒适）、温度均匀性（温差≤5°C）、降频阈值余量。", "tags": ["TDP", "热设计", "评估方法"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-006	mock-kb-phone-heat	\N	note	{"title": "导热界面材料（TIM）选型指南", "content": "芯片与散热片之间的界面热阻是散热瓶颈。常用TIM：1) 导热硅脂（导热系数1-3 W/mK，易干涸）；2) 导热凝胶（3-8 W/mK，长效稳定）；3) 导热垫（1-6 W/mK，易装配）；4) 液态金属（20-80 W/mK，需防腐蚀封装）。选型需平衡导热系数、界面热阻、长期稳定性、装配工艺和成本。手机中多用导热凝胶兼顾性能与可靠性。", "tags": ["TIM", "界面热阻", "导热材料"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-007	mock-kb-phone-heat	\N	note	{"title": "手机AI温控策略优化", "content": "传统温控基于阈值反馈（温度超限→降频），存在滞后性。AI温控通过机器学习预测温度趋势，提前调节：1) 采集CPU/GPU负载、环境温度、历史温度时序；2) LSTM/Transformer模型预测未来5-10秒温度；3) 预测超限则提前降频/降亮度。优势：减少温度峰值、降低降频次数、提升用户体验。挑战：模型轻量化、在线推理延迟、个性化适配。", "tags": ["AI温控", "预测调频", "机器学习"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-008	mock-kb-phone-heat	\N	note	{"title": "手机散热结构集成度演进", "content": "手机散热结构演进：1) 第一代：导热硅脂+石墨片（被动散热，覆盖日常）；2) 第二代：VC均热板（相变散热，覆盖游戏场景）；3) 第三代：VC+石墨烯+相变材料复合（多机制协同）；4) 第四代：液冷+风冷+AI主动散热（游戏手机）。趋势：从被动到主动、从单点到全域、从硬件到软硬协同。", "tags": ["散热演进", "集成度", "技术趋势"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-009	mock-kb-phone-heat	\N	note	{"title": "5G手机发热挑战与对策", "content": "5G手机发热较4G更严重：1) 毫米波PA功耗高（发射功率大）；2) 天线数量多（MIMO）；3) 基带处理复杂（高频段信号处理）；4) 高速数据传输（GPU/内存负载）。对策：1) PA近端独立散热；2) 天线隔离避免热耦合；3) 动态调制（信号弱时降速降功耗）；4) 智能切换4G/5G（非高速场景用4G）。", "tags": ["5G", "功耗", "PA散热"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-010	mock-kb-phone-heat	\N	note	{"title": "手机快充发热抑制技术", "content": "快充发热主要来自充电IC和电池内阻。抑制技术：1) 电荷泵技术（降压比固定，效率达97%+，减少IC发热）；2) 分流充电（双电芯串联充电并联放电，降低单芯电流）；3) 隔离式充电（充电IC外置充电头，手机端仅接收低压）；4) 动态功率调节（温度升高时降低充电功率）；5) 充电散热联动（快充时启动辅助散热）。", "tags": ["快充", "电荷泵", "充电发热"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-011	mock-kb-phone-heat	\N	note	{"title": "手机散热CFD仿真建模要点", "content": "CFD仿真用于手机热设计优化。建模要点：1) 几何简化（保留关键散热路径，忽略小特征）；2) 材料属性（各向异性导热，如石墨片面内vs面外导热差异大）；3) 边界条件（自然对流5-25 W/m²K、辐射ε=0.9、手持热阻）；4) 网格（芯片区加密，y+适配湍流模型）；5) 求解（稳态+瞬态结合）。验证：与红外热像仪实测对比，误差<2°C。", "tags": ["CFD", "仿真", "热设计"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
mock-note-012	mock-kb-phone-heat	\N	note	{"title": "手机散热材料导热系数对比", "content": "常用散热材料导热系数（W/mK）：铜（400）、铝（237）、石墨烯面内（3000-5000）、高定向热解石墨（1500-2000）、普通石墨片（400-1500）、导热凝胶（3-8）、导热硅脂（1-3）、相变材料（0.2-0.5，需增强）。选型需综合考虑导热、厚度、柔性、成本、可加工性。手机中石墨片性价比最高，VC性能最优，石墨烯为前沿方向。", "tags": ["导热系数", "材料对比", "选型"], "source": "mock-seed"}	completed	\N	2026-07-04 00:59:19	2026-07-04 00:59:19
\.


--
-- Data for Name: knowledge_jobs; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_jobs (id, job_type, queue, input_data, status, attempt, max_attempts, timeout_ms, parent_job_id, idempotency_key, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_vectors; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.knowledge_vectors (id, user_id, base_id, item_id, chunk_index, text, embedding, created_at) FROM stdin;
\.


--
-- Data for Name: model_providers; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.model_providers (id, provider_id, name, protocol, api_host, api_model, models, max_rpm, current_rpm, request_count, is_enabled, last_used_at, last_reset_at, created_at, updated_at) FROM stdin;
1	deepseek	DeepSeek	openai	https://api.deepseek.com		["deepseek-v4-flash"]	60	0	0	1	\N	\N	2026-07-03 23:52:00	2026-07-03 23:52:00
2	silicon	SiliconFlow	openai	https://api.siliconflow.cn		["Qwen/Qwen3-Embedding-8B", "Qwen/Qwen3-Reranker-8B"]	60	0	0	1	\N	\N	2026-07-03 23:52:00	2026-07-03 23:52:00
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.models (id, provider_id, model_id, name, capabilities, endpoint_types, context_window, max_output_tokens, max_input_tokens, model_group, is_enabled, metadata, created_at, updated_at) FROM stdin;
1	deepseek	deepseek-v4-flash		[]	[]	0	0	0		1	{}	2026-07-04 00:58:46	2026-07-04 00:58:46
2	silicon	Qwen/Qwen3-Embedding-8B		[]	[]	0	0	0		1	{}	2026-07-04 00:58:46	2026-07-04 00:58:46
3	silicon	Qwen/Qwen3-Reranker-8B		[]	[]	0	0	0		1	{}	2026-07-04 00:58:46	2026-07-04 00:58:46
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.notifications (id, user_id, title, content, type, is_read, is_recalled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: patent_vectors; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.patent_vectors (patent_id, embedding, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: patents; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.patents (id, title, abstract, applicants, inventors, filing_date, publication_date, patent_number, ipc_codes, relevance_score, publication_number, claims, description, created_at, updated_at) FROM stdin;
1	一种智能手机石墨烯散热结构	本发明涉及手机散热技术领域，公开一种智能手机石墨烯散热结构，包括石墨烯导热层和石墨烯散热膜，通过石墨烯的高导热系数实现快速均温散热，有效降低手机局部热点温度。	["华为技术有限公司"]	["张明", "李华"]	2023-03-15	2023-09-20	CN115672345A	["H01M10/6533", "H05K7/20"]	96		1.一种智能手机石墨烯散热结构，其特征在于包括石墨烯导热层...	详细描述石墨烯散热结构的层叠设计、制备工艺及散热性能测试结果。	2026-07-04 00:59:19	2026-07-04 00:59:19
2	手机均热板VC散热装置	本发明公开一种手机均热板VC散热装置，利用真空腔体内工质相变实现高效热量传递，散热功率较传统石墨片提升3倍以上。	["OPPO广东移动通信有限公司"]	["王强", "刘伟"]	2023-01-20	2023-07-15	CN115432189A	["H05K7/20", "H01M10/625"]	94		1.一种手机均热板VC散热装置，其特征在于包括真空腔体、毛细吸液芯...	描述VC均热板的结构设计、毛细吸液芯材料选择及充液率优化。	2026-07-04 00:59:19	2026-07-04 00:59:19
3	基于相变材料的手机热管理系统	本发明涉及手机热管理技术，采用石蜡基相变材料作为储热介质，在手机发热峰值时吸收潜热，延缓温度上升速率。	["小米通讯技术有限公司"]	["陈晓", "赵磊"]	2023-05-10	2023-11-25	CN115890123A	["H05K7/20", "H01M10/6586"]	92		1.一种基于相变材料的手机热管理系统，其特征在于包括相变储热层...	详细描述相变材料的封装结构、导热增强填料及热响应特性。	2026-07-04 00:59:19	2026-07-04 00:59:19
4	手机芯片液冷散热模组	本发明公开一种手机芯片液冷散热模组，采用微通道液冷板配合微型泵驱动冷却液循环，实现芯片定点高效散热。	["维沃移动通信有限公司"]	["孙杰", "周涛"]	2023-02-18	2023-08-30	CN115567890A	["H05K7/20", "H01L23/427"]	90		1.一种手机芯片液冷散热模组，其特征在于包括微通道散热板...	描述微通道液冷板的结构、流道设计及泵驱动控制策略。	2026-07-04 00:59:19	2026-07-04 00:59:19
5	智能手机多级散热架构	本发明涉及手机多级散热架构，通过导热硅脂、石墨片、VC均热板三级串联，实现从芯片到外壳的高效热传导路径。	["荣耀终端有限公司"]	["吴敏", "郑华"]	2023-04-05	2023-10-18	CN115789012A	["H05K7/20"]	89		1.一种智能手机多级散热架构，其特征在于包括三级导热层...	描述三级散热架构的层间界面热阻优化及温度梯度控制。	2026-07-04 00:59:19	2026-07-04 00:59:19
6	手机AI智能温控方法及系统	本发明公开一种手机AI智能温控方法，通过机器学习预测芯片发热趋势，动态调节CPU频率和屏幕亮度以降低发热。	["华为技术有限公司"]	["黄涛", "林峰"]	2023-06-12	2023-12-20	CN115901234A	["H05K7/20", "G06N20/00"]	88		1.一种手机AI智能温控方法，其特征在于包括温度预测模型...	描述基于LSTM的温度预测模型训练及动态调频策略。	2026-07-04 00:59:19	2026-07-04 00:59:19
7	手机石墨片导热结构	本发明涉及手机石墨散热技术，采用高定向热解石墨片，导热系数达1500W/mK，实现大面积均温散热。	["三星电子株式会社"]	["Kim Sanghoon", "Lee Minho"]	2023-02-28	2023-08-15	CN115456789A	["H05K7/20", "C01B32/00"]	87		1.一种手机石墨片导热结构，其特征在于包括高定向热解石墨层...	描述石墨片的制备工艺、厚度优化及贴合方式。	2026-07-04 00:59:19	2026-07-04 00:59:19
8	手机散热风冷结构	本发明公开一种手机散热风冷结构，利用手机内部空气对流通道，配合微型风扇实现主动风冷散热。	["联想创新有限公司"]	["胡军", "郭明"]	2023-03-22	2023-09-28	CN115678901A	["H05K7/20", "F28D9/00"]	85		1.一种手机散热风冷结构，其特征在于包括内部对流通道...	描述风冷通道设计、微型风扇布局及气流组织优化。	2026-07-04 00:59:19	2026-07-04 00:59:19
9	手机电池热管理装置	本发明涉及手机电池热管理，采用导热凝胶包裹电池，配合温度传感器实现电池过热保护和寿命延长。	["宁德时代新能源科技股份有限公司"]	["曾毓群", "李晨"]	2023-04-18	2023-10-30	CN115812345A	["H01M10/6533", "H01M10/625"]	84		1.一种手机电池热管理装置，其特征在于包括导热凝胶层...	描述导热凝胶配方、电池包覆工艺及热失控防护策略。	2026-07-04 00:59:19	2026-07-04 00:59:19
10	手机柔性屏散热背板	本发明公开一种手机柔性屏散热背板，采用超薄石墨烯-铜箔复合散热层，兼顾柔性与高导热。	["京东方科技集团股份有限公司"]	["徐明", "高伟"]	2023-05-25	2023-11-30	CN115923456A	["H05K7/20", "H01L23/367"]	83		1.一种手机柔性屏散热背板，其特征在于包括石墨烯-铜箔复合层...	描述复合散热层的层叠结构、柔性测试及导热性能。	2026-07-04 00:59:19	2026-07-04 00:59:19
11	手机游戏场景智能散热方法	本发明涉及手机游戏场景散热，根据游戏负载动态调节散热策略，结合帧率与温度协同控制。	["腾讯科技（深圳）有限公司"]	["马化腾", "张志东"]	2023-07-08	2024-01-15	CN116012345A	["H05K7/20", "G06F9/50"]	82		1.一种手机游戏场景智能散热方法，其特征在于包括负载预测模块...	描述游戏场景识别、负载预测及散热策略动态切换。	2026-07-04 00:59:19	2026-07-04 00:59:19
12	手机超薄VC均热板制备方法	本发明公开一种手机超薄VC均热板制备方法，厚度仅0.3mm，通过蚀刻工艺形成微毛细结构。	["瑞声科技控股有限公司"]	["潘政民", "吴春媛"]	2023-01-15	2023-07-08	CN115423456A	["H05K7/20", "B23K26/00"]	81		1.一种手机超薄VC均热板制备方法，其特征在于包括蚀刻毛细结构步骤...	描述超薄VC的蚀刻工艺、毛细结构设计及性能测试。	2026-07-04 00:59:19	2026-07-04 00:59:19
13	手机散热石墨烯涂层	本发明涉及手机散热涂层技术，在手机内壳表面涂覆石墨烯散热涂层，实现大面积辐射散热。	["比亚迪股份有限公司"]	["王传福", "廉玉波"]	2023-06-20	2023-12-28	CN115934567A	["H05K7/20", "C09D5/00"]	80		1.一种手机散热石墨烯涂层，其特征在于包括石墨烯分散液...	描述石墨烯涂层的配方、涂覆工艺及辐射散热系数测试。	2026-07-04 00:59:19	2026-07-04 00:59:19
14	手机热管散热模组	本发明公开一种手机热管散热模组，采用扁平热管将芯片热量快速传导至手机中框，实现远端散热。	["东莞华贝电子科技有限公司"]	["陈明", "杨光"]	2023-03-08	2023-09-15	CN115645678A	["H05K7/20", "H01L23/427"]	79		1.一种手机热管散热模组，其特征在于包括扁平热管...	描述扁平热管的结构、工质选择及弯曲性能测试。	2026-07-04 00:59:19	2026-07-04 00:59:19
15	手机多热源协同散热系统	本发明涉及手机多热源散热，针对CPU、GPU、电池、充电IC多热源设计协同散热路径。	["中兴通讯股份有限公司"]	["李自学", "王喜瑜"]	2023-08-12	2024-02-15	CN116023456A	["H05K7/20"]	78		1.一种手机多热源协同散热系统，其特征在于包括多热源温度采集...	描述多热源温度采集、热流分配算法及协同控制策略。	2026-07-04 00:59:19	2026-07-04 00:59:19
16	手机充电散热一体化结构	本发明公开一种手机充电散热一体化结构，在快充时启动辅助散热，降低充电发热。	["OPPO广东移动通信有限公司"]	["刘作虎", "沈义人"]	2023-04-22	2023-10-25	CN115745678A	["H05K7/20", "H02J7/00"]	77		1.一种手机充电散热一体化结构，其特征在于包括充电散热联动...	描述充电散热联动控制、快充温升抑制及安全保护。	2026-07-04 00:59:19	2026-07-04 00:59:19
17	手机散热仿真优化方法	本发明涉及手机散热仿真技术，通过CFD仿真优化手机内部散热结构设计，减少热阻。	["北京字节跳动网络技术有限公司"]	["梁汝波", "张利东"]	2023-09-15	2024-03-20	CN116034567A	["H05K7/20", "G06F30/15"]	76		1.一种手机散热仿真优化方法，其特征在于包括CFD建模步骤...	描述CFD仿真建模、热阻分析及结构优化迭代。	2026-07-04 00:59:19	2026-07-04 00:59:19
18	手机导热凝胶组合物	本发明公开一种手机导热凝胶组合物，导热系数达8W/mK，用于芯片与散热片之间界面导热。	["深圳新宙邦科技股份有限公司"]	["覃九三", "邓先红"]	2023-02-10	2023-08-05	CN115434567A	["H05K7/20", "C08L83/04"]	75		1.一种手机导热凝胶组合物，其特征在于包括硅橡胶基体...	描述导热凝胶配方、氧化铝填料改性及界面热阻测试。	2026-07-04 00:59:19	2026-07-04 00:59:19
19	手机外壳辐射散热涂层	本发明涉及手机外壳散热，在外壳表面涂覆高发射率红外辐射涂层，提升辐射散热效率。	["富士康科技集团有限公司"]	["郭台铭", "戴正吴"]	2023-05-18	2023-11-20	CN115845678A	["H05K7/20", "C09D5/33"]	74		1.一种手机外壳辐射散热涂层，其特征在于包括高发射率填料...	描述辐射散热涂层的配方、发射率测试及耐久性评估。	2026-07-04 00:59:19	2026-07-04 00:59:19
20	手机散热翅片结构	本发明公开一种手机散热翅片结构，在手机中框集成微型散热翅片，增加散热面积。	["闻泰科技股份有限公司"]	["张学政", "肖学礼"]	2023-07-22	2024-01-28	CN116045678A	["H05K7/20", "F28F3/02"]	73		1.一种手机散热翅片结构，其特征在于包括微型翅片阵列...	描述微型翅片的几何设计、加工工艺及散热性能提升。	2026-07-04 00:59:19	2026-07-04 00:59:19
21	手机热分区管理方法	本发明涉及手机热分区管理，将手机内部分为多个热区，独立采集温度并分区控制散热。	["魅族科技有限公司"]	["黄章", "白永祥"]	2023-03-28	2023-10-05	CN115656789A	["H05K7/20", "G06F1/20"]	72		1.一种手机热分区管理方法，其特征在于包括热区划分...	描述热区划分策略、分区温度采集及独立散热控制。	2026-07-04 00:59:19	2026-07-04 00:59:19
22	手机石墨烯-碳纳米管复合散热膜	本发明公开一种手机石墨烯-碳纳米管复合散热膜，结合石墨烯面内导热和碳纳米管轴向导热优势。	["深圳烯旺先进材料技术有限公司"]	["冯冠平", "李俊江"]	2023-04-15	2023-10-22	CN115756789A	["H05K7/20", "C01B32/00"]	71		1.一种手机石墨烯-碳纳米管复合散热膜，其特征在于包括复合层...	描述复合散热膜的制备、界面结合及各向异性导热测试。	2026-07-04 00:59:19	2026-07-04 00:59:19
23	手机散热自适应控制方法	本发明涉及手机散热自适应控制，根据环境温度和使用场景动态调整散热策略。	["努比亚技术有限公司"]	["里强", "倪飞"]	2023-08-28	2024-02-28	CN116056789A	["H05K7/20", "G06F1/20"]	70		1.一种手机散热自适应控制方法，其特征在于包括场景识别...	描述场景识别、环境温度补偿及散热策略自适应切换。	2026-07-04 00:59:19	2026-07-04 00:59:19
24	手机3D均热板结构	本发明公开一种手机3D均热板结构，采用立体腔体设计，实现多面散热和折叠屏适配。	["柔宇科技股份有限公司"]	["刘自鸿", "余晓军"]	2023-06-08	2023-12-15	CN115967890A	["H05K7/20", "H01L23/427"]	69		1.一种手机3D均热板结构，其特征在于包括立体腔体...	描述3D均热板的立体腔体设计、折叠适配及散热性能。	2026-07-04 00:59:19	2026-07-04 00:59:19
25	手机散热微胶囊相变材料	本发明涉及手机散热相变材料，采用微胶囊封装石蜡，实现相变材料的稳定性和可加工性。	["中国科学技术大学"]	["陈初升", "陈春华"]	2023-01-08	2023-07-05	CN115412345A	["H05K7/20", "C09K5/02"]	68		1.一种手机散热微胶囊相变材料，其特征在于包括微胶囊壁材...	描述微胶囊制备、壁材选择及相变储热性能测试。	2026-07-04 00:59:19	2026-07-04 00:59:19
26	手机热感应变色警示结构	本发明公开一种手机热感应变色警示结构，在手机外壳集成热敏变色材料，直观显示发热区域。	["深圳传音控股股份有限公司"]	["竺兆江", "阿里夫"]	2023-09-22	2024-03-15	CN116067890A	["H05K7/20", "C09K9/02"]	67		1.一种手机热感应变色警示结构，其特征在于包括热敏变色层...	描述热敏变色材料选择、变色阈值设计及警示显示方案。	2026-07-04 00:59:19	2026-07-04 00:59:19
27	手机散热石墨片贴合工艺	本发明涉及手机石墨片贴合工艺，采用自动化贴合设备实现石墨片高精度无气泡贴合。	["伯恩光学（惠州）有限公司"]	["杨建文", "吴明"]	2023-02-25	2023-08-20	CN115445678A	["H05K7/20", "B32B37/00"]	66		1.一种手机散热石墨片贴合工艺，其特征在于包括预定位步骤...	描述贴合工艺流程、气泡消除及贴合精度控制。	2026-07-04 00:59:19	2026-07-04 00:59:19
28	手机液冷+风冷混合散热系统	本发明公开一种手机液冷+风冷混合散热系统，结合液冷高导热和风冷主动散热优势。	["黑鲨科技有限公司"]	["吴世敏", "罗语周"]	2023-05-05	2023-11-10	CN115856789A	["H05K7/20", "H01L23/427"]	65		1.一种手机液冷+风冷混合散热系统，其特征在于包括液冷回路...	描述混合散热系统的液冷回路设计、风扇布局及协同控制。	2026-07-04 00:59:19	2026-07-04 00:59:19
29	手机散热性能测试方法	本发明涉及手机散热性能测试，采用红外热像仪和多点温度传感器组合测试方案。	["中国信息通信研究院"]	["王志勤", "何宝宏"]	2023-10-12	2024-04-15	CN116078901A	["H05K7/20", "G01K13/00"]	64		1.一种手机散热性能测试方法，其特征在于包括红外热像采集...	描述测试方案设计、温度采集点布置及散热性能评估指标。	2026-07-04 00:59:19	2026-07-04 00:59:19
30	手机散热均温板表面处理方法	本发明公开一种手机散热均温板表面处理方法，通过亲水涂层提升毛细吸液芯的毛细力。	["双鸿科技股份有限公司"]	["蔡文斌", "林建宏"]	2023-03-15	2023-09-22	CN115667890A	["H05K7/20", "C23C14/00"]	63		1.一种手机散热均温板表面处理方法，其特征在于包括亲水涂层沉积...	描述亲水涂层材料、沉积工艺及毛细力提升效果。	2026-07-04 00:59:19	2026-07-04 00:59:19
31	手机折叠屏散热铰链结构	本发明涉及折叠屏手机散热，在铰链处集成柔性导热件，实现展开和折叠状态下的持续散热。	["三星电子株式会社"]	["Park Jihyun", "Choi Donghoon"]	2023-07-15	2024-01-20	CN116089012A	["H05K7/20", "H04M1/02"]	62		1.一种手机折叠屏散热铰链结构，其特征在于包括柔性导热件...	描述柔性导热件设计、铰链集成及折叠耐久测试。	2026-07-04 00:59:19	2026-07-04 00:59:19
32	手机散热AI预测温控算法	本发明公开一种手机散热AI预测温控算法，基于使用习惯和环境数据预测未来温度趋势，提前调节散热。	["高通股份有限公司"]	["Cristiano Amon", "Alex Katouzian"]	2023-11-08	2024-05-10	CN116090123A	["H05K7/20", "G06N20/00"]	61		1.一种手机散热AI预测温控算法，其特征在于包括温度趋势预测模型...	描述预测模型训练、特征工程及提前散热调节策略。	2026-07-04 00:59:19	2026-07-04 00:59:19
33	手机散热超薄热管阵列	本发明涉及手机超薄热管阵列，多根微型热管并联布置，实现大面积高效均温。	["奇鋐科技股份有限公司"]	["沈庆洲", "黄俊雄"]	2023-04-28	2023-11-05	CN115778901A	["H05K7/20", "H01L23/427"]	60		1.一种手机散热超薄热管阵列，其特征在于包括多根微型热管...	描述热管阵列布局、并联设计及均温性能测试。	2026-07-04 00:59:19	2026-07-04 00:59:19
\.


--
-- Data for Name: problem_modelings; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.problem_modelings (id, task_id, problem_elements, conflicts, recommended_principles, innovation_directions, model_structure, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: solutions; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.solutions (id, task_id, title, description, principles, confidence_score, patent_references, rating, created_at, updated_at) FROM stdin;
1	6	石墨烯-VC复合多级散热方案	采用石墨烯导热层（芯片界面）+ VC均热板（中段均温）+ 石墨片（外壳均温）三级串联散热架构。芯片热量经导热凝胶传至石墨烯层快速扩散，VC均热板通过相变将热量传导至大面积冷凝区，最终由石墨片均匀分布至手机外壳。实测热点温度降低6-8°C，温差控制在3°C以内。	["分割原理", "局部质量原理", "多孔材料原理"]	92	["一种智能手机石墨烯散热结构", "手机均热板VC散热装置"]	5	2026-07-04 00:59:19	2026-07-04 00:59:19
2	6	AI预测+相变储热智能温控方案	结合AI温度预测模型和相变储热材料，实现主动+被动协同温控。AI模型基于CPU/GPU负载、环境温度预测未来10秒温度趋势，提前降频；相变材料（石蜡基，相变温度42°C）在发热峰值吸收潜热，延缓温度上升。双重机制使温度峰值降低4-5°C，降频次数减少60%。	["动态性原理", "相变原理", "预先作用原理"]	88	["手机AI智能温控方法及系统", "基于相变材料的手机热管理系统"]	4	2026-07-04 00:59:19	2026-07-04 00:59:19
3	6	液冷+风冷混合主动散热方案	针对游戏手机场景，设计液冷+风冷混合散热系统。微通道液冷板覆盖SoC和充电IC，微型泵驱动冷却液循环；手机内部对流通道配合微型风扇实现主动风冷。液冷负责高功率热源定点散热，风冷负责全域均温。散热功率达15W，支持满载游戏2小时无降频。	["复合材料原理", "分割原理", "动态性原理"]	85	["手机芯片液冷散热模组", "手机液冷+风冷混合散热系统"]	4	2026-07-04 00:59:19	2026-07-04 00:59:19
4	7	PA近端独立散热+动态功率调节方案	为5G PA设计独立散热岛，采用超薄热管将PA热量传导至手机中框远端散热；配合动态功率控制，信号弱时降低PA输出功率减少发热。实测PA区域温度降低5°C，5G续航提升12%。	["分割原理", "动态性原理", "预先作用原理"]	86	["手机热管散热模组", "手机散热自适应控制方法"]	4	2026-07-04 00:59:19	2026-07-04 00:59:19
5	8	电荷泵+双电芯分流+散热联动快充方案	采用电荷泵技术将充电效率提升至97%以上，减少IC发热；双电芯串联充电并联放电降低单芯电流；快充时启动VC均热板辅助散热。综合方案使充电温升降低8°C，100W快充全程温度<42°C。	["分割原理", "局部质量原理", "动态性原理"]	89	["手机充电散热一体化结构", "手机电池热管理装置"]	5	2026-07-04 00:59:19	2026-07-04 00:59:19
6	9	铰链集成柔性石墨烯导热件方案	在折叠铰链处集成柔性石墨烯-聚酰亚胺复合导热件，展开时导热件平直导热，折叠时导热件弯曲保持热路连通。配合3D均热板实现多面散热。实测展开/折叠状态热点温差<2°C，折叠耐久>30万次。	["柔性壳体原理", "分割原理", "复合材料原理"]	84	["手机折叠屏散热铰链结构", "手机3D均热板结构"]	4	2026-07-04 00:59:19	2026-07-04 00:59:19
7	10	热分区隔离+协同调度多热源管理方案	将手机内部分为5个热区（SoC区、GPU区、电池区、充电IC区、PA区），各区独立温度采集与散热控制；热区之间采用隔热材料隔离减少热耦合；全局AI调度器根据各热区负载协同分配散热资源。实测多热源场景温度降低5-7°C，热耦合减少40%。	["分割原理", "动态性原理", "多孔材料原理"]	87	["手机多热源协同散热系统", "手机热分区管理方法"]	5	2026-07-04 00:59:19	2026-07-04 00:59:19
8	11	高发射率辐射涂层+微型翅片外壳散热方案	在手机外壳内表面涂覆高发射率红外辐射涂层（发射率ε>0.95），提升辐射散热效率；外壳中框集成微型散热翅片增加对流散热面积。综合方案使外壳散热量提升35%，内部温度降低3-4°C。	["面化原理", "多孔材料原理", "复合材料原理"]	82	["手机外壳辐射散热涂层", "手机散热翅片结构"]	4	2026-07-04 00:59:19	2026-07-04 00:59:19
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.system_settings (id, key, value, updated_at) FROM stdin;
1	chat_model	deepseek:deepseek-v4-flash	2026-07-04 00:25:44
2	embedding_model	silicon:Qwen/Qwen3-Embedding-8B	2026-07-04 00:25:44
3	rerank_model	silicon:Qwen/Qwen3-Reranker-8B	2026-07-04 00:25:44
4	extract_model	deepseek:deepseek-v4-flash	2026-07-04 00:25:44
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.tasks (id, user_id, title, description, tags, status, created_at, updated_at) FROM stdin;
5	0	手机发热	手机发热	[]	pending	2026-07-04 00:49:24	2026-07-04 00:57:24
6	0	手机发热问题综合解决方案	针对智能手机在高负载场景（游戏、快充、5G）下的发热问题，设计多级协同散热方案，降低热点温度并提升用户体验。	[]	completed	2026-07-04 00:59:19	2026-07-04 00:59:19
7	0	5G手机射频前端发热优化方案	5G毫米波PA功耗高导致射频前端发热严重，设计PA近端独立散热与动态功率调节方案。	[]	completed	2026-07-04 00:59:19	2026-07-04 00:59:19
8	0	手机快充发热抑制方案	快充场景充电IC和电池发热严重，设计电荷泵+分流充电+散热联动方案。	[]	completed	2026-07-04 00:59:19	2026-07-04 00:59:19
9	0	折叠屏手机散热结构设计	折叠屏手机铰链区域散热路径中断，设计柔性导热件实现展开/折叠状态持续散热。	[]	completed	2026-07-04 00:59:19	2026-07-04 00:59:19
10	0	手机多热源协同热管理方案	手机内SoC、GPU、电池、充电IC、PA多热源相互热耦合，设计热分区独立管理与协同散热方案。	[]	completed	2026-07-04 00:59:19	2026-07-04 00:59:19
11	0	手机外壳辐射散热增强方案	手机外壳辐射散热效率低，设计高发射率涂层+散热翅片结构增强外壳散热。	[]	completed	2026-07-04 00:59:19	2026-07-04 00:59:19
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.users (id, username, password_hash, role, email, is_active, created_at, token_version, updated_at) FROM stdin;
0	admin@innovos.com		admin		1	2026-07-03 23:52:00	0	2026-07-03 23:52:00
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: innovos
--

COPY public.workflows (id, task_id, status, steps, created_at, updated_at) FROM stdin;
5	5	awaiting_rating	[{"agent_id": "agent1", "agent_type": "problem_analysis", "agent_label": "\\u9700\\u6c42\\u6d1e\\u5bdfAgent", "description": "\\u8bc6\\u522b 6 \\u4e2a\\u9700\\u6c42", "status": "completed", "started_at": "2026-07-04T00:49:24.713064", "completed_at": "2026-07-04T00:49:58.565884", "duration": "33.9s", "output": "{\\"resource_analysis\\": {\\"substance_resources\\": [{\\"name\\": \\"\\u624b\\u673a\\u5185\\u90e8\\u7ec4\\u4ef6\\", \\"description\\": \\"\\u7535\\u6c60\\u3001CPU\\u3001\\u5c4f\\u5e55\\u3001\\u5916\\u58f3\\u7b49\\u4ea7\\u70ed\\u90e8\\u4ef6\\", \\"available\\": true}, {\\"name\\": \\"\\u6563\\u70ed\\u6750\\u6599\\", \\"description\\": \\"\\u77f3\\u58a8\\u7247\\u3001\\u5bfc\\u70ed\\u7845\\u8102\\u3001\\u5747\\u70ed\\u677f\\u7b49\\u5df2\\u7528\\u6750\\u6599\\", \\"available\\": true}, {\\"name\\": \\"\\u5916\\u90e8\\u73af\\u5883\\", \\"description\\": \\"\\u7a7a\\u6c14\\u3001\\u684c\\u9762\\u3001\\u6563\\u70ed\\u80cc\\u5939\\u7b49\\u53ef\\u8f85\\u52a9\\u6563\\u70ed\\", \\"available\\": true}], \\"energy_resources\\": [{\\"name\\": \\"\\u70ed\\u573a\\", \\"description\\": \\"\\u53d1\\u70ed\\u4ea7\\u751f\\u7684\\u70ed\\u80fd\\", \\"available\\": true}, {\\"name\\": \\"\\u7535\\u573a\\", \\"description\\": \\"\\u4f9b\\u7535\\u7535\\u6e90\\", \\"available\\": true}, {\\"name\\": \\"\\u673a\\u68b0\\u573a\\", \\"description\\": \\"\\u98ce\\u6247\\u3001\\u632f\\u52a8\\u9a6c\\u8fbe\\u7b49\\", \\"available\\": true}, {\\"name\\": \\"\\u91cd\\u529b\\u573a\\", \\"description\\": \\"\\u81ea\\u7136\\u5bf9\\u6d41\\u53d7\\u91cd\\u529b\\u5f71\\u54cd\\", \\"available\\": true}], \\"information_resources\\": [{\\"name\\": \\"\\u6e29\\u5ea6\\u4f20\\u611f\\u5668\\u6570\\u636e\\", \\"description\\": \\"\\u5b9e\\u65f6\\u76d1\\u6d4b\\u5404\\u90e8\\u4ef6\\u6e29\\u5ea6\\", \\"available\\": true}, {\\"name\\": \\"CPU\\u8d1f\\u8f7d\\", \\"description\\": \\"\\u5904\\u7406\\u5668\\u4f7f\\u7528\\u7387\\", \\"available\\": true}, {\\"name\\": \\"\\u7535\\u6c60\\u7535\\u91cf\\", \\"description\\": \\"\\u7535\\u6c60\\u72b6\\u6001\\", \\"available\\": true}, {\\"name\\": \\"\\u7528\\u6237\\u4f7f\\u7528\\u4e60\\u60ef\\", \\"description\\": \\"\\u64cd\\u4f5c\\u9891\\u7387\\u3001\\u5e94\\u7528\\u7c7b\\u578b\\", \\"available\\": true}], \\"time_resources\\": [{\\"name\\": \\"\\u7a7a\\u95f2\\u65f6\\u95f4\\", \\"description\\": \\"\\u5f85\\u673a\\u3001\\u5145\\u7535\\u65f6\\u65e0\\u9ad8\\u8d1f\\u8f7d\\", \\"available\\": true}, {\\"name\\": \\"\\u64cd\\u4f5c\\u95f4\\u9699\\", \\"description\\": \\"\\u5207\\u6362\\u5e94\\u7528\\u3001\\u5c4f\\u5e55\\u5173\\u95ed\\u95f4\\u9699\\", \\"available\\": true}], \\"space_resources\\": [{\\"name\\": \\"\\u624b\\u673a\\u5185\\u90e8\\u7a7a\\u9699\\", \\"description\\": \\"PCB\\u95f4\\u3001\\u7535\\u6c60\\u4e0e\\u5916\\u58f3\\u95f4\\u7a7a\\u9699\\", \\"available\\": true}, {\\"name\\": \\"\\u624b\\u673a\\u5916\\u58f3\\u8868\\u9762\\", \\"description\\": \\"\\u540e\\u76d6\\u3001\\u8fb9\\u6846\\u53ef\\u63a5\\u89e6\\u5916\\u90e8\\", \\"available\\": true}, {\\"name\\": \\"\\u5916\\u90e8\\u7a7a\\u95f4\\", \\"description\\": \\"\\u624b\\u673a\\u5468\\u56f4\\u7a7a\\u6c14\\u3001\\u684c\\u9762\\", \\"available\\": true}], \\"functional_resources\\": [{\\"name\\": \\"\\u4f20\\u611f\\u5668\\", \\"description\\": \\"\\u6e29\\u5ea6\\u3001\\u538b\\u529b\\u3001\\u52a0\\u901f\\u5ea6\\u4f20\\u611f\\u5668\\", \\"available\\": true}, {\\"name\\": \\"\\u5904\\u7406\\u5668\\", \\"description\\": \\"CPU/GPU\\u53ef\\u8c03\\u5ea6\\u964d\\u9891\\", \\"available\\": true}, {\\"name\\": \\"\\u5c4f\\u5e55\\", \\"description\\": \\"\\u663e\\u793a\\u4eae\\u5ea6\\u53ef\\u8c03\\u8282\\", \\"available\\": true}, {\\"name\\": \\"\\u5145\\u7535\\u5668\\", \\"description\\": \\"\\u5145\\u7535\\u534f\\u8bae\\u53ef\\u9650\\u5236\\u7535\\u6d41\\", \\"available\\": true}, {\\"name\\": \\"\\u4fdd\\u62a4\\u58f3\\", \\"description\\": \\"\\u6563\\u70ed\\u5b54\\u8bbe\\u8ba1\\u6216\\u5bfc\\u70ed\\u6750\\u6599\\", \\"available\\": true}], \\"system_resources\\": [{\\"name\\": \\"\\u64cd\\u4f5c\\u7cfb\\u7edf\\", \\"description\\": \\"\\u4efb\\u52a1\\u8c03\\u5ea6\\u3001\\u6e29\\u63a7\\u7b56\\u7565\\", \\"available\\": true}, {\\"name\\": \\"\\u56fa\\u4ef6\\", \\"description\\": \\"\\u5e95\\u5c42\\u529f\\u8017\\u7ba1\\u7406\\", \\"available\\": true}, {\\"name\\": \\"\\u8f6f\\u786c\\u4ef6\\u534f\\u540c\\", \\"description\\": \\"APP\\u4e0e\\u786c\\u4ef6\\u8054\\u52a8\\u63a7\\u5236\\", \\"available\\": true}], \\"summary\\": \\"\\u624b\\u673a\\u53d1\\u70ed\\u95ee\\u9898\\u6d89\\u53ca\\u70ed\\u573a\\u3001\\u4fe1\\u606f\\u8d44\\u6e90\\u548c\\u7a7a\\u95f4\\u8d44\\u6e90\\u7684\\u6838\\u5fc3\\u5229\\u7528\\u3002\\u5f53\\u524d\\u5df2\\u4f7f\\u7528\\u90e8\\u5206\\u6563\\u70ed\\u6750\\u6599\\u548c\\u6e29\\u63a7\\u7b56\\u7565\\uff0c\\u4f46\\u53ef\\u8fdb\\u4e00\\u6b65\\u6316\\u6398\\u70ed\\u573a\\uff08\\u5982\\u6e29\\u5dee\\u53d1\\u7535\\uff09\\u3001\\u65f6\\u95f4\\u8d44\\u6e90\\uff08\\u7a7a\\u95f2\\u6563\\u70ed\\uff09\\u3001\\u7a7a\\u95f4\\u8d44\\u6e90\\uff08\\u4f18\\u5316\\u5185\\u90e8\\u6d41\\u9053\\uff09\\u4ee5\\u53ca\\u7cfb\\u7edf\\u8d44\\u6e90\\u7684\\u667a\\u80fd\\u8c03\\u5ea6\\u3002\\u4fe1\\u606f\\u8d44\\u6e90\\u7684\\u5b9e\\u65f6\\u53cd\\u9988\\u53ef\\u63d0\\u5347\\u9884\\u6d4b\\u6027\\u6563\\u70ed\\u3002\\", \\"priority_resources\\": [{\\"name\\": \\"\\u70ed\\u573a\\u80fd\\u91cf\\", \\"reason\\": \\"\\u53d1\\u70ed\\u672c\\u8eab\\u5c31\\u662f\\u4e00\\u79cd\\u53ef\\u7528\\u80fd\\u91cf\\uff0c\\u53ef\\u8f6c\\u5316\\u4e3a\\u7535\\u80fd\\u6216\\u7528\\u4e8e\\u89e6\\u53d1\\u88ab\\u52a8\\u6563\\u70ed\\"}, {\\"name\\": \\"\\u6e29\\u5ea6\\u4f20\\u611f\\u5668\\u4fe1\\u606f\\", \\"reason\\": \\"\\u5b9e\\u65f6\\u7cbe\\u51c6\\u7684\\u6e29\\u5ea6\\u6570\\u636e\\u662f\\u667a\\u80fd\\u6e29\\u63a7\\u51b3\\u7b56\\u7684\\u57fa\\u7840\\"}, {\\"name\\": \\"\\u5185\\u90e8\\u7a7a\\u95f4\\", \\"reason\\": \\"\\u4f18\\u5316\\u5185\\u90e8\\u7a7a\\u6c14\\u5bf9\\u6d41\\u6216\\u589e\\u52a0\\u76f8\\u53d8\\u6750\\u6599\\u53ef\\u663e\\u8457\\u63d0\\u5347\\u6563\\u70ed\\u6548\\u7387\\"}]}, \\"ideal_final_result\\": {\\"ifr_1_statement\\": \\"\\u624b\\u673a\\u81ea\\u8eab\\u5b9e\\u73b0\\u6563\\u70ed\\u529f\\u80fd\\uff0c\\u65e0\\u9700\\u989d\\u5916\\u6563\\u70ed\\u88c5\\u7f6e\\u6216\\u7528\\u6237\\u5e72\\u9884\\u3002\\", \\"ifr_2_statement\\": \\"\\u901a\\u8fc7X\\u5143\\u7d20\\u5b9e\\u73b0\\u6563\\u70ed\\uff0cX\\u5143\\u7d20\\u7531\\u624b\\u673a\\u73b0\\u6709\\u7ed3\\u6784\\u6216\\u6750\\u6599\\u4ea7\\u751f\\u3002\\", \\"x_element\\": \\"\\u624b\\u673a\\u5185\\u90e8\\u7684\\u5bfc\\u70ed\\u6750\\u6599\\u548c\\u7ed3\\u6784\\uff0c\\u5982\\u91d1\\u5c5e\\u4e2d\\u6846\\u3001\\u77f3\\u58a8\\u6563\\u70ed\\u7247\\u7b49\\uff0c\\u5229\\u7528\\u81ea\\u8eab\\u90e8\\u4ef6\\u9ad8\\u6548\\u5bfc\\u70ed\\u5e76\\u81ea\\u7136\\u6563\\u70ed\\u3002\\", \\"physical_contradiction\\": {\\"parameter\\": \\"\\u6563\\u70ed\\u9762\\u79ef\\", \\"requirement_a\\": \\"\\u9700\\u8981\\u8db3\\u591f\\u5927\\u7684\\u6563\\u70ed\\u9762\\u79ef\\u4ee5\\u5feb\\u901f\\u6563\\u70ed\\", \\"requirement_b\\": \\"\\u9700\\u8981\\u4fdd\\u6301\\u624b\\u673a\\u8f7b\\u8584\\u5c0f\\u5de7\\uff0c\\u4e0d\\u80fd\\u589e\\u52a0\\u6563\\u70ed\\u9762\\u79ef\\"}, \\"operating_time\\": \\"\\u624b\\u673a\\u8fd0\\u884c\\u671f\\u95f4\\uff0c\\u7279\\u522b\\u662f\\u9ad8\\u8d1f\\u8f7d\\u65f6\\uff08\\u5982\\u6e38\\u620f\\u3001\\u5145\\u7535\\uff09\\u3002\\", \\"operating_zone\\": \\"\\u624b\\u673a\\u5185\\u90e8\\u82af\\u7247\\u53ca\\u7535\\u6c60\\u533a\\u57df\\uff0c\\u4ee5\\u53ca\\u624b\\u673a\\u5916\\u58f3\\u3002\\", \\"what_to_eliminate\\": \\"\\u624b\\u673a\\u53d1\\u70ed\\u73b0\\u8c61\\u53ca\\u56e0\\u53d1\\u70ed\\u5bfc\\u81f4\\u7684\\u6027\\u80fd\\u4e0b\\u964d\\u3001\\u7528\\u6237\\u4e0d\\u9002\\u3002\\", \\"what_to_achieve\\": \\"\\u624b\\u673a\\u5728\\u8fd0\\u884c\\u8fc7\\u7a0b\\u4e2d\\u4fdd\\u6301\\u9002\\u5b9c\\u6e29\\u5ea6\\uff0c\\u65e0\\u9700\\u5916\\u90e8\\u6563\\u70ed\\u63aa\\u65bd\\u3002\\", \\"constraints\\": [\\"\\u4e0d\\u589e\\u52a0\\u989d\\u5916\\u6563\\u70ed\\u5143\\u4ef6\\", \\"\\u4e0d\\u6539\\u53d8\\u624b\\u673a\\u5916\\u89c2\\u5c3a\\u5bf8\\", \\"\\u4e0d\\u5f71\\u54cd\\u624b\\u673a\\u6027\\u80fd\\", \\"\\u6210\\u672c\\u4e0d\\u663e\\u8457\\u589e\\u52a0\\"], \\"key_parameters\\": [\\"\\u6e29\\u5ea6\\", \\"\\u6563\\u70ed\\u901f\\u7387\\", \\"\\u5bfc\\u70ed\\u7cfb\\u6570\\"], \\"measurement_criteria\\": [\\"\\u6700\\u9ad8\\u6e29\\u5ea6\\u4f4e\\u4e8e40\\u00b0C\\", \\"\\u6e29\\u5ea6\\u5747\\u5300\\u6027\\", \\"\\u6563\\u70ed\\u54cd\\u5e94\\u65f6\\u95f4\\"], \\"ifr_1_to_2_reasoning\\": \\"\\u7531\\u4e8e\\u624b\\u673a\\u81ea\\u8eab\\u65e0\\u6cd5\\u5b8c\\u5168\\u5b9e\\u73b0\\u7406\\u60f3\\u6563\\u70ed\\uff0c\\u9700\\u8981\\u501f\\u52a9\\u73b0\\u6709\\u8d44\\u6e90\\uff08\\u5982\\u673a\\u58f3\\u3001\\u7535\\u6c60\\u7b49\\uff09\\u4f5c\\u4e3aX\\u5143\\u7d20\\u6765\\u8f85\\u52a9\\u6563\\u70ed\\u3002\\", \\"contradiction_derivation\\": \\"\\u8981\\u5b9e\\u73b0\\u9ad8\\u6548\\u6563\\u70ed\\u9700\\u8981\\u589e\\u5927\\u6563\\u70ed\\u9762\\u79ef\\uff0c\\u4f46\\u589e\\u5927\\u9762\\u79ef\\u4e0e\\u8f7b\\u8584\\u8bbe\\u8ba1\\u77db\\u76fe\\uff0c\\u56e0\\u6b64\\u901a\\u8fc7\\u4f18\\u5316\\u5185\\u90e8\\u5bfc\\u70ed\\u8def\\u5f84\\u548c\\u5229\\u7528\\u73b0\\u6709\\u7ed3\\u6784\\u4f5c\\u4e3a\\u6563\\u70ed\\u4f53\\u6765\\u8c03\\u548c\\u77db\\u76fe\\u3002\\"}, \\"nine_screens\\": {\\"screens\\": {\\"supersystem\\": {\\"past\\": \\"\\u73af\\u5883\\u6e29\\u5ea6\\u8f83\\u4f4e\\uff0c\\u7528\\u6237\\u4f7f\\u7528\\u5f3a\\u5ea6\\u5c0f\\uff0c\\u7f51\\u7edc\\u901f\\u5ea6\\u6162\\", \\"present\\": \\"\\u73af\\u5883\\u6e29\\u5ea6\\u5347\\u9ad8\\uff0c\\u7528\\u6237\\u4f7f\\u7528\\u9ad8\\u5f3a\\u5ea6\\u5e94\\u7528\\uff0c\\u7f51\\u7edc\\u901f\\u5ea6\\u5feb\\", \\"future\\": \\"\\u53ef\\u80fd\\u53d1\\u5c55\\u51fa\\u66f4\\u597d\\u7684\\u6563\\u70ed\\u5916\\u90e8\\u8bbe\\u5907\\u6216\\u73af\\u5883\\u63a7\\u5236\\uff0c\\u5982\\u4e3b\\u52a8\\u6563\\u70ed\\u58f3\\"}, \\"system\\": {\\"past\\": \\"\\u624b\\u673a\\u53d1\\u70ed\\u95ee\\u9898\\u8f83\\u5c11\\uff0c\\u6027\\u80fd\\u9700\\u6c42\\u4f4e\\", \\"present\\": \\"\\u624b\\u673a\\u53d1\\u70ed\\u6210\\u4e3a\\u5e38\\u89c1\\u95ee\\u9898\\uff0c\\u9ad8\\u6027\\u80fd\\u5904\\u7406\\u5668\\u70ed\\u91cf\\u5927\\", \\"future\\": \\"\\u901a\\u8fc7\\u8f6f\\u4ef6\\u4f18\\u5316\\u3001\\u786c\\u4ef6\\u6539\\u8fdb\\u6216\\u65b0\\u6750\\u6599\\u51cf\\u5c11\\u53d1\\u70ed\\"}, \\"subsystem\\": {\\"past\\": \\"\\u5904\\u7406\\u5668\\u6027\\u80fd\\u8f83\\u4f4e\\uff0c\\u53d1\\u70ed\\u4e0d\\u660e\\u663e\\", \\"present\\": \\"\\u9ad8\\u6027\\u80fd\\u5904\\u7406\\u5668\\u3001\\u7535\\u6c60\\u7b49\\u7ec4\\u4ef6\\u53d1\\u70ed\\u4e25\\u91cd\\", \\"future\\": \\"\\u91c7\\u7528\\u66f4\\u9ad8\\u6548\\u7684\\u6563\\u70ed\\u6280\\u672f\\uff0c\\u5982\\u6db2\\u51b7\\u3001\\u77f3\\u58a8\\u70ef\\"}}, \\"insights\\": [\\"\\u624b\\u673a\\u53d1\\u70ed\\u4e0e\\u6027\\u80fd\\u63d0\\u5347\\u76f4\\u63a5\\u76f8\\u5173\\uff0c\\u6563\\u70ed\\u6280\\u672f\\u662f\\u5173\\u952e\\u74f6\\u9888\\", \\"\\u7528\\u6237\\u4f7f\\u7528\\u884c\\u4e3a\\u548c\\u73af\\u5883\\u56e0\\u7d20\\u52a0\\u5267\\u4e86\\u53d1\\u70ed\\u95ee\\u9898\\"], \\"contradictions\\": [\\"\\u6027\\u80fd\\u63d0\\u5347\\u4e0e\\u6563\\u70ed\\u6548\\u7387\\u7684\\u77db\\u76fe\\uff0c\\u5373\\u9ad8\\u6027\\u80fd\\u9700\\u8981\\u66f4\\u597d\\u7684\\u6563\\u70ed\\u4f46\\u53d7\\u9650\\u4e8e\\u7a7a\\u95f4\\u548c\\u6210\\u672c\\", \\"\\u8f7b\\u8584\\u8bbe\\u8ba1\\u4e0e\\u6563\\u70ed\\u80fd\\u529b\\u7684\\u77db\\u76fe\\uff0c\\u5373\\u8ffd\\u6c42\\u8f7b\\u8584\\u5bfc\\u81f4\\u6563\\u70ed\\u7a7a\\u95f4\\u4e0d\\u8db3\\"]}, \\"goldfish\\": {\\"fantasy_solution\\": \\"\\u624b\\u673a\\u5b8c\\u5168\\u4e0d\\u53d1\\u70ed\\", \\"achievable_parts\\": [\\"\\u88ab\\u52a8\\u6563\\u70ed\\u8bbe\\u8ba1\\", \\"\\u4f4e\\u529f\\u8017\\u82af\\u7247\\", \\"\\u8f6f\\u4ef6\\u4f18\\u5316\\u51cf\\u5c11\\u8d1f\\u8f7d\\"], \\"breakthrough_parts\\": [\\"\\u96f6\\u529f\\u8017\\u6563\\u70ed\\u6750\\u6599\\", \\"\\u5b8c\\u5168\\u65e0\\u70ed\\u635f\\u8017\\u80fd\\u91cf\\u8f6c\\u6362\\"], \\"constraints\\": [\\"\\u7269\\u7406\\u5b9a\\u5f8b\\uff1a\\u80fd\\u91cf\\u8f6c\\u6362\\u5fc5\\u7136\\u4ea7\\u751f\\u70ed\\u91cf\\"], \\"iterations\\": [{\\"step\\": 1, \\"description\\": \\"\\u5206\\u89e3\\u5e7b\\u60f3\\uff1a\\u624b\\u673a\\u5b8c\\u5168\\u4e0d\\u53d1\\u70ed\\u3002\\u53ef\\u5b9e\\u73b0\\u90e8\\u5206\\uff1a\\u4f7f\\u7528\\u9ad8\\u6548\\u6563\\u70ed\\u6280\\u672f\\u548c\\u4f4e\\u529f\\u8017\\u5143\\u5668\\u4ef6\\u3002\\u9700\\u7a81\\u7834\\u90e8\\u5206\\uff1a\\u6d88\\u9664\\u6240\\u6709\\u70ed\\u91cf\\u4ea7\\u751f\\u3002\\u7ea6\\u675f\\uff1a\\u70ed\\u529b\\u5b66\\u7b2c\\u4e8c\\u5b9a\\u5f8b\\u3002\\"}, {\\"step\\": 2, \\"description\\": \\"\\u91cd\\u65b0\\u5b9a\\u4e49\\u95ee\\u9898\\uff1a\\u5982\\u4f55\\u8ba9\\u624b\\u673a\\u70ed\\u91cf\\u4e0d\\u5f71\\u54cd\\u7528\\u6237\\u4f53\\u9a8c\\u6216\\u5feb\\u901f\\u6d88\\u6563\\uff1f\\"}], \\"final_solution\\": \\"\\u91c7\\u7528\\u76f8\\u53d8\\u6563\\u70ed\\u6750\\u6599\\u3001\\u77f3\\u58a8\\u70ef\\u5bfc\\u70ed\\u3001\\u667a\\u80fd\\u9891\\u7387\\u8c03\\u8282\\u548c\\u4e3b\\u52a8\\u51b7\\u5374\\u7cfb\\u7edf\\uff0c\\u5c06\\u70ed\\u91cf\\u63a7\\u5236\\u5728\\u53ef\\u63a5\\u53d7\\u8303\\u56f4\\", \\"insights\\": [\\"\\u70ed\\u91cf\\u4e0d\\u53ef\\u80fd\\u5b8c\\u5168\\u6d88\\u9664\\uff0c\\u4f46\\u53ef\\u901a\\u8fc7\\u70ed\\u7ba1\\u7406\\u548c\\u7528\\u6237\\u4f53\\u9a8c\\u8bbe\\u8ba1\\u89e3\\u51b3\\", \\"\\u5c06\\u70ed\\u91cf\\u8f6c\\u5316\\u4e3a\\u5176\\u4ed6\\u5f62\\u5f0f\\uff08\\u5982\\u7535\\u80fd\\uff09\\u662f\\u672a\\u6765\\u65b9\\u5411\\"]}, \\"stc\\": {\\"size_zero\\": \\"\\u5c3a\\u5bf8\\u4e3a\\u96f6\\u65f6\\uff0c\\u624b\\u673a\\u4e0d\\u5b58\\u5728\\uff0c\\u65e0\\u53d1\\u70ed\\u95ee\\u9898\\u3002\\", \\"size_infinite\\": \\"\\u5c3a\\u5bf8\\u65e0\\u7a77\\u5927\\u65f6\\uff0c\\u6563\\u70ed\\u9762\\u79ef\\u5de8\\u5927\\uff0c\\u53d1\\u70ed\\u95ee\\u9898\\u6d88\\u5931\\uff0c\\u4f46\\u5931\\u53bb\\u4fbf\\u643a\\u6027\\u3002\\", \\"time_zero\\": \\"\\u65f6\\u95f4\\u4e3a\\u96f6\\u65f6\\uff0c\\u77ac\\u65f6\\u53d1\\u70ed\\u5bfc\\u81f4\\u7acb\\u5373\\u635f\\u574f\\uff0c\\u4f46\\u6982\\u7387\\u6781\\u4f4e\\u3002\\", \\"time_infinite\\": \\"\\u65f6\\u95f4\\u65e0\\u7a77\\u5927\\u65f6\\uff0c\\u6301\\u7eed\\u53d1\\u70ed\\u7d2f\\u79ef\\uff0c\\u53ef\\u80fd\\u5f15\\u53d1\\u7535\\u6c60\\u7206\\u70b8\\u6216\\u786c\\u4ef6\\u5931\\u6548\\u3002\\", \\"cost_zero\\": \\"\\u6210\\u672c\\u4e3a\\u96f6\\u65f6\\uff0c\\u4f9d\\u8d56\\u81ea\\u7136\\u6563\\u70ed\\u6216\\u88ab\\u52a8\\u4f18\\u5316\\uff0c\\u6548\\u679c\\u6709\\u9650\\u3002\\", \\"cost_infinite\\": \\"\\u6210\\u672c\\u65e0\\u7a77\\u5927\\u65f6\\uff0c\\u53ef\\u91c7\\u7528\\u6db2\\u51b7\\u3001\\u76f8\\u53d8\\u6750\\u6599\\u7b49\\u5c16\\u7aef\\u6280\\u672f\\uff0c\\u5f7b\\u5e95\\u89e3\\u51b3\\u53d1\\u70ed\\u3002\\", \\"insights\\": [\\"\\u624b\\u673a\\u53d1\\u70ed\\u662f\\u80fd\\u91cf\\u5bc6\\u5ea6\\u4e0e\\u6563\\u70ed\\u80fd\\u529b\\u7684\\u77db\\u76fe\\uff0c\\u9700\\u5e73\\u8861\\u6027\\u80fd\\u4e0e\\u6e29\\u5ea6\\u3002\\", \\"\\u589e\\u5927\\u5c3a\\u5bf8\\u53ef\\u6539\\u5584\\u6563\\u70ed\\uff0c\\u4f46\\u727a\\u7272\\u4fbf\\u643a\\u6027\\uff1b\\u63d0\\u9ad8\\u6210\\u672c\\u53ef\\u5f15\\u5165\\u4e3b\\u52a8\\u6563\\u70ed\\u65b9\\u6848\\u3002\\"], \\"contradictions\\": [\\"\\u5c0f\\u5c3a\\u5bf8\\u4fbf\\u643a\\u4e0e\\u5927\\u9762\\u79ef\\u6563\\u70ed\\u4e4b\\u95f4\\u7684\\u77db\\u76fe\\u3002\\", \\"\\u77ac\\u65f6\\u9ad8\\u6e29\\u4fdd\\u62a4\\u4e0e\\u6301\\u7eed\\u7a33\\u5b9a\\u8fd0\\u884c\\u4e4b\\u95f4\\u7684\\u77db\\u76fe\\u3002\\", \\"\\u4f4e\\u6210\\u672c\\u4e0e\\u9ad8\\u6548\\u6563\\u70ed\\u6280\\u672f\\u4e4b\\u95f4\\u7684\\u77db\\u76fe\\u3002\\"]}, \\"demands\\": [{\\"id\\": \\"d1\\", \\"source\\": \\"\\u8d44\\u6e90\\u5206\\u6790\\", \\"category\\": \\"\\u529f\\u80fd\\u9700\\u6c42\\", \\"description\\": \\"\\u624b\\u673a\\u5728\\u73a9\\u6e38\\u620f\\u65f6\\u4e0d\\u4f1a\\u70eb\\u624b\\", \\"priority\\": 0.8, \\"user_rating\\": null}, {\\"id\\": \\"d2\\", \\"source\\": \\"IFR\\u7406\\u60f3\\u89e3\\", \\"category\\": \\"\\u6027\\u80fd\\u9700\\u6c42\\", \\"description\\": \\"\\u624b\\u673a\\u957f\\u65f6\\u95f4\\u9ad8\\u8d1f\\u8f7d\\u8fd0\\u884c\\u65f6\\u4e0d\\u964d\\u9891\\u5361\\u987f\\", \\"priority\\": 0.8, \\"user_rating\\": null}, {\\"id\\": \\"d3\\", \\"source\\": \\"STC\\u7b97\\u5b50\\", \\"category\\": \\"\\u5b89\\u5168\\u9700\\u6c42\\", \\"description\\": \\"\\u624b\\u673a\\u7535\\u6c60\\u4e0d\\u4f1a\\u56e0\\u8fc7\\u70ed\\u800c\\u635f\\u574f\\u6216\\u7206\\u70b8\\", \\"priority\\": 0.8, \\"user_rating\\": null}, {\\"id\\": \\"d4\\", \\"source\\": \\"IFR\\u7406\\u60f3\\u89e3\\", \\"category\\": \\"\\u7528\\u6237\\u4f53\\u9a8c\\u9700\\u6c42\\", \\"description\\": \\"\\u624b\\u673a\\u673a\\u8eab\\u6e29\\u5ea6\\u5747\\u5300\\uff0c\\u4e0d\\u4f1a\\u5c40\\u90e8\\u8fc7\\u70eb\\", \\"priority\\": 0.8, \\"user_rating\\": null}, {\\"id\\": \\"d5\\", \\"source\\": \\"\\u91d1\\u9c7c\\u6cd5\\", \\"category\\": \\"\\u7eed\\u822a\\u9700\\u6c42\\", \\"description\\": \\"\\u624b\\u673a\\u5145\\u7535\\u65f6\\u53d1\\u70ed\\u5c0f\\uff0c\\u4e0d\\u5f71\\u54cd\\u5145\\u7535\\u901f\\u5ea6\\u548c\\u7535\\u6c60\\u5bff\\u547d\\", \\"priority\\": 0.8, \\"user_rating\\": null}, {\\"id\\": \\"d6\\", \\"source\\": \\"\\u4e5d\\u5c4f\\u5e55\\u6cd5\\", \\"category\\": \\"\\u6210\\u672c\\u9700\\u6c42\\", \\"description\\": \\"\\u4e0d\\u9700\\u8981\\u989d\\u5916\\u8d2d\\u4e70\\u6563\\u70ed\\u914d\\u4ef6\\uff0c\\u624b\\u673a\\u81ea\\u8eab\\u6563\\u70ed\\u591f\\u7528\\", \\"priority\\": 0.8, \\"user_rating\\": null}], \\"ratings\\": [{\\"demandId\\": \\"d1\\", \\"score\\": 4}, {\\"demandId\\": \\"d2\\", \\"score\\": 4}, {\\"demandId\\": \\"d3\\", \\"score\\": 3}, {\\"demandId\\": \\"d4\\", \\"score\\": 4}, {\\"demandId\\": \\"d5\\", \\"score\\": 4}, {\\"demandId\\": \\"d6\\", \\"score\\": 5}]}"}, {"agent_id": "agent2", "agent_type": "patent_search", "agent_label": "\\u95ee\\u9898\\u5efa\\u6a21Agent", "description": "\\u751f\\u6210 6 \\u4e2a\\u521b\\u65b0\\u65b9\\u5411", "status": "completed", "started_at": "2026-07-04T00:56:20.502759", "completed_at": "2026-07-04T00:57:24.661320", "duration": "64.2s", "output": "{\\"resource_analysis\\": {\\"substance_resources\\": [{\\"name\\": \\"\\u6563\\u70ed\\u6750\\u6599\\", \\"description\\": \\"\\u624b\\u673a\\u5185\\u90e8\\u53ef\\u80fd\\u4f7f\\u7528\\u77f3\\u58a8\\u7247\\u3001\\u5bfc\\u70ed\\u51dd\\u80f6\\u7b49\\u6563\\u70ed\\u6750\\u6599\\", \\"available\\": true}, {\\"name\\": \\"\\u91d1\\u5c5e\\u5916\\u58f3\\", \\"description\\": \\"\\u90e8\\u5206\\u624b\\u673a\\u4f7f\\u7528\\u91d1\\u5c5e\\u4e2d\\u6846\\u6216\\u80cc\\u677f\\u8f85\\u52a9\\u6563\\u70ed\\", \\"available\\": true}, {\\"name\\": \\"\\u7a7a\\u6c14\\", \\"description\\": \\"\\u624b\\u673a\\u5468\\u56f4\\u7a7a\\u6c14\\u53ef\\u5e26\\u8d70\\u70ed\\u91cf\\", \\"available\\": true}, {\\"name\\": \\"\\u70ed\\u7ba1/\\u5747\\u6e29\\u677f\\", \\"description\\": \\"\\u90e8\\u5206\\u9ad8\\u7aef\\u624b\\u673a\\u5185\\u7f6e\\u70ed\\u7ba1\\u6216\\u5747\\u6e29\\u677f\\", \\"available\\": true}], \\"energy_resources\\": [{\\"name\\": \\"\\u70ed\\u80fd\\", \\"description\\": \\"\\u82af\\u7247\\u4ea7\\u751f\\u7684\\u70ed\\u80fd\\u4e3a\\u95ee\\u9898\\u672c\\u8eab\\", \\"available\\": true}, {\\"name\\": \\"\\u7535\\u80fd\\", \\"description\\": \\"\\u7535\\u6c60\\u4f9b\\u7535\\u8f6c\\u5316\\u4e3a\\u70ed\\u80fd\\", \\"available\\": true}, {\\"name\\": \\"\\u673a\\u68b0\\u80fd\\", \\"description\\": \\"\\u632f\\u52a8\\u9a6c\\u8fbe\\u3001\\u98ce\\u6247\\uff08\\u5982\\u6709\\uff09\\u53ef\\u8f85\\u52a9\\u6563\\u70ed\\", \\"available\\": false}, {\\"name\\": \\"\\u8f90\\u5c04\\uff08\\u7ea2\\u5916\\uff09\\", \\"description\\": \\"\\u624b\\u673a\\u901a\\u8fc7\\u70ed\\u8f90\\u5c04\\u6563\\u70ed\\", \\"available\\": true}], \\"information_resources\\": [{\\"name\\": \\"\\u6e29\\u5ea6\\u4f20\\u611f\\u5668\\", \\"description\\": \\"\\u624b\\u673a\\u5185\\u7f6e\\u6e29\\u5ea6\\u4f20\\u611f\\u5668\\u53ef\\u76d1\\u6d4b\\u53d1\\u70ed\\u60c5\\u51b5\\", \\"available\\": true}, {\\"name\\": \\"\\u7528\\u6237\\u89e6\\u611f\\u53cd\\u9988\\", \\"description\\": \\"\\u7528\\u6237\\u624b\\u611f\\u6e29\\u5ea6\\u4f5c\\u4e3a\\u53cd\\u9988\\", \\"available\\": true}, {\\"name\\": \\"\\u529f\\u8017\\u6570\\u636e\\", \\"description\\": \\"APP\\u529f\\u8017\\u3001CPU\\u5360\\u7528\\u7b49\\u6570\\u636e\\u53ef\\u9884\\u6d4b\\u53d1\\u70ed\\", \\"available\\": true}, {\\"name\\": \\"\\u73af\\u5883\\u6e29\\u5ea6\\", \\"description\\": \\"\\u5916\\u90e8\\u73af\\u5883\\u6e29\\u5ea6\\u5f71\\u54cd\\u6563\\u70ed\\", \\"available\\": true}], \\"time_resources\\": [{\\"name\\": \\"\\u7a7a\\u95f2\\u65f6\\u95f4\\", \\"description\\": \\"\\u624b\\u673a\\u5f85\\u673a\\u6216\\u4f4e\\u8d1f\\u8f7d\\u65f6\\u6e29\\u5ea6\\u4e0b\\u964d\\", \\"available\\": true}, {\\"name\\": \\"\\u8109\\u51b2\\u5f0f\\u64cd\\u4f5c\\u65f6\\u95f4\\", \\"description\\": \\"\\u77ed\\u6682\\u9ad8\\u8d1f\\u8f7d\\u540e\\u95f4\\u6b47\\u65f6\\u95f4\\u53ef\\u6563\\u70ed\\", \\"available\\": true}, {\\"name\\": \\"\\u5145\\u7535\\u65f6\\u95f4\\", \\"description\\": \\"\\u5145\\u7535\\u65f6\\u53d1\\u70ed\\uff0c\\u53ef\\u8d81\\u6b64\\u65f6\\u95f4\\u4e3b\\u52a8\\u6563\\u70ed\\", \\"available\\": true}], \\"space_resources\\": [{\\"name\\": \\"\\u624b\\u673a\\u5185\\u90e8\\u7a7a\\u95f4\\", \\"description\\": \\"PCB\\u5e03\\u5c40\\u3001\\u5c4f\\u853d\\u7f69\\u7b49\\u672a\\u5145\\u5206\\u5229\\u7528\\u7684\\u7a7a\\u95f4\\", \\"available\\": true}, {\\"name\\": \\"\\u624b\\u673a\\u80cc\\u9762\\u4e0e\\u624b\\u638c\\u95f4\\u7a7a\\u9699\\", \\"description\\": \\"\\u63e1\\u6301\\u65f6\\u624b\\u638c\\u4e0e\\u624b\\u673a\\u95f4\\u7a7a\\u6c14\\u5c42\\", \\"available\\": true}, {\\"name\\": \\"\\u624b\\u673a\\u5916\\u90e8\\u7a7a\\u95f4\\", \\"description\\": \\"\\u5468\\u56f4\\u7a7a\\u6c14\\u6d41\\u52a8\\u7a7a\\u95f4\\", \\"available\\": true}, {\\"name\\": \\"\\u5c4f\\u5e55\\u4e0e\\u673a\\u8eab\\u8fb9\\u7f18\\", \\"description\\": \\"\\u53ef\\u8bbe\\u8ba1\\u6563\\u70ed\\u7ed3\\u6784\\u7684\\u4f4d\\u7f6e\\", \\"available\\": true}], \\"functional_resources\\": [{\\"name\\": \\"\\u5904\\u7406\\u5668\\u964d\\u9891\\u529f\\u80fd\\", \\"description\\": \\"\\u901a\\u8fc7\\u964d\\u9891\\u51cf\\u5c11\\u53d1\\u70ed\\", \\"available\\": true}, {\\"name\\": \\"\\u98ce\\u6247/\\u6563\\u70ed\\u5668\\u529f\\u80fd\\", \\"description\\": \\"\\u90e8\\u5206\\u6e38\\u620f\\u624b\\u673a\\u5185\\u7f6e\\u98ce\\u6247\\", \\"available\\": false}, {\\"name\\": \\"\\u7535\\u6c60\\u7ba1\\u7406\\u529f\\u80fd\\", \\"description\\": \\"\\u9650\\u5236\\u5145\\u7535\\u7535\\u6d41\\u6216\\u7535\\u538b\\u63a7\\u6e29\\", \\"available\\": true}, {\\"name\\": \\"\\u5916\\u58f3\\u5bfc\\u70ed\\u529f\\u80fd\\", \\"description\\": \\"\\u5229\\u7528\\u91d1\\u5c5e\\u90e8\\u4ef6\\u4f20\\u5bfc\\u70ed\\u91cf\\", \\"available\\": true}], \\"system_resources\\": [{\\"name\\": \\"\\u624b\\u673a\\u5916\\u58f3\\", \\"description\\": \\"\\u5916\\u58f3\\u672c\\u8eab\\u53ef\\u4f5c\\u4e3a\\u6563\\u70ed\\u754c\\u9762\\", \\"available\\": true}, {\\"name\\": \\"\\u4e3b\\u677f\\u4e0e\\u82af\\u7247\\", \\"description\\": \\"\\u4e3b\\u8981\\u70ed\\u6e90\\uff0c\\u53ef\\u4f18\\u5316\\u5e03\\u5c40\\", \\"available\\": true}, {\\"name\\": \\"\\u7535\\u6c60\\", \\"description\\": \\"\\u53d1\\u70ed\\u6e90\\u4e4b\\u4e00\\uff0c\\u53ef\\u8bbe\\u8ba1\\u6563\\u70ed\\u8def\\u5f84\\", \\"available\\": true}, {\\"name\\": \\"\\u5c4f\\u5e55\\", \\"description\\": \\"\\u90e8\\u5206\\u70ed\\u91cf\\u53ef\\u901a\\u8fc7\\u5c4f\\u5e55\\u6563\\u51fa\\", \\"available\\": true}], \\"summary\\": \\"\\u624b\\u673a\\u53d1\\u70ed\\u95ee\\u9898\\u4e3b\\u8981\\u6d89\\u53ca\\u70ed\\u80fd\\u8d44\\u6e90\\u7684\\u4ea7\\u751f\\u4e0e\\u8017\\u6563\\u3002\\u5f53\\u524d\\u5df2\\u5229\\u7528\\u90e8\\u5206\\u6563\\u70ed\\u6750\\u6599\\u3001\\u4f20\\u611f\\u5668\\u548c\\u964d\\u9891\\u529f\\u80fd\\uff0c\\u4f46\\u4ecd\\u6709\\u672a\\u5145\\u5206\\u5229\\u7528\\u7684\\u7a7a\\u95f4\\uff08\\u5982\\u5185\\u90e8\\u7a7a\\u9699\\uff09\\u3001\\u65f6\\u95f4\\uff08\\u7a7a\\u95f2\\u95f4\\u9699\\uff09\\u548c\\u529f\\u80fd\\uff08\\u5982\\u98ce\\u6247\\uff09\\u3002\\", \\"priority_resources\\": [{\\"name\\": \\"\\u70ed\\u7ba1/\\u5747\\u6e29\\u677f\\", \\"reason\\": \\"\\u76f4\\u63a5\\u6539\\u5584\\u70ed\\u4f20\\u5bfc\\uff0c\\u9ad8\\u6548\\u5229\\u7528\\u5185\\u90e8\\u7a7a\\u95f4\\"}, {\\"name\\": \\"\\u6e29\\u5ea6\\u4f20\\u611f\\u5668+\\u529f\\u8017\\u6570\\u636e\\", \\"reason\\": \\"\\u63d0\\u4f9b\\u5b9e\\u65f6\\u4fe1\\u606f\\uff0c\\u53ef\\u52a8\\u6001\\u8c03\\u6574\\u6563\\u70ed\\u7b56\\u7565\\"}, {\\"name\\": \\"\\u7a7a\\u6c14\\u6d41\\u52a8\\u7a7a\\u95f4\\", \\"reason\\": \\"\\u901a\\u8fc7\\u8bbe\\u8ba1\\u58f3\\u4f53\\u98ce\\u9053\\u6216\\u5229\\u7528\\u63e1\\u6301\\u95f4\\u9699\\u589e\\u5f3a\\u5bf9\\u6d41\\"}]}, \\"evolution_trend\\": {}, \\"sufield_analysis\\": {\\"s1\\": \\"\\u5185\\u90e8\\u70ed\\u6e90\\", \\"s2\\": \\"\\u624b\\u673a\\u5916\\u58f3\\", \\"f\\": \\"\\u70ed\\u573a\\", \\"problem_type\\": \\"non_measurement\\", \\"effect_type\\": \\"harmful\\"}, \\"function_analysis\\": {\\"system_components\\": [{\\"name\\": \\"CPU\\", \\"description\\": \\"\\u5904\\u7406\\u8ba1\\u7b97\\u4efb\\u52a1\\uff0c\\u4ea7\\u751f\\u70ed\\u91cf\\"}, {\\"name\\": \\"\\u7535\\u6c60\\", \\"description\\": \\"\\u4f9b\\u7535\\u548c\\u50a8\\u80fd\\uff0c\\u5145\\u653e\\u7535\\u65f6\\u53d1\\u70ed\\"}, {\\"name\\": \\"\\u5c4f\\u5e55\\", \\"description\\": \\"\\u663e\\u793a\\u5185\\u5bb9\\uff0c\\u80cc\\u5149\\u8017\\u7535\\u53d1\\u70ed\\"}, {\\"name\\": \\"\\u5916\\u58f3\\", \\"description\\": \\"\\u5c01\\u88c5\\u5185\\u90e8\\u7ec4\\u4ef6\\uff0c\\u4f20\\u5bfc\\u70ed\\u91cf\\u5230\\u5916\\u90e8\\"}, {\\"name\\": \\"\\u6563\\u70ed\\u6a21\\u5757\\", \\"description\\": \\"\\u5305\\u62ec\\u6563\\u70ed\\u7247\\u3001\\u77f3\\u58a8\\u7247\\u7b49\\uff0c\\u5e2e\\u52a9\\u6563\\u70ed\\"}, {\\"name\\": \\"\\u6e29\\u5ea6\\u4f20\\u611f\\u5668\\", \\"description\\": \\"\\u76d1\\u6d4b\\u7cfb\\u7edf\\u6e29\\u5ea6\\"}, {\\"name\\": \\"\\u64cd\\u4f5c\\u7cfb\\u7edf/\\u8f6f\\u4ef6\\", \\"description\\": \\"\\u7ba1\\u7406\\u529f\\u8017\\u548c\\u8c03\\u5ea6\\uff0c\\u5f71\\u54cd\\u53d1\\u70ed\\"}], \\"supersystem_components\\": [{\\"name\\": \\"\\u7528\\u6237\\", \\"description\\": \\"\\u624b\\u6301\\u624b\\u673a\\uff0c\\u611f\\u77e5\\u53d1\\u70ed\\uff0c\\u53ef\\u8c03\\u6574\\u4f7f\\u7528\\u65b9\\u5f0f\\"}, {\\"name\\": \\"\\u73af\\u5883\\u7a7a\\u6c14\\", \\"description\\": \\"\\u4e0e\\u5916\\u58f3\\u8fdb\\u884c\\u70ed\\u4ea4\\u6362\\uff0c\\u6563\\u70ed\\"}, {\\"name\\": \\"\\u5145\\u7535\\u5668\\", \\"description\\": \\"\\u63d0\\u4f9b\\u5145\\u7535\\u7535\\u6d41\\uff0c\\u5bfc\\u81f4\\u7535\\u6c60\\u53d1\\u70ed\\"}, {\\"name\\": \\"\\u7f51\\u7edc\\u4fe1\\u53f7\\", \\"description\\": \\"\\u4fe1\\u53f7\\u5f31\\u65f6\\u5c04\\u9891\\u6a21\\u5757\\u9ad8\\u529f\\u7387\\u5de5\\u4f5c\\u53d1\\u70ed\\"}, {\\"name\\": \\"\\u5e94\\u7528\\u7a0b\\u5e8f\\", \\"description\\": \\"\\u8fd0\\u884c\\u8d1f\\u8f7d\\uff0c\\u5f71\\u54cdCPU\\u4f7f\\u7528\\u7387\\"}], \\"key_interactions\\": [{\\"tool\\": \\"CPU\\", \\"receiver\\": \\"\\u6563\\u70ed\\u6a21\\u5757\\", \\"type\\": \\"\\u4e0d\\u8db3\\", \\"verb\\": \\"\\u4f20\\u5bfc\\u70ed\\u91cf\\"}, {\\"tool\\": \\"\\u7535\\u6c60\\", \\"receiver\\": \\"CPU\\", \\"type\\": \\"\\u6b63\\u5e38\\", \\"verb\\": \\"\\u4f9b\\u7535\\u4ea7\\u751f\\u70ed\\u91cf\\"}, {\\"tool\\": \\"\\u7528\\u6237\\", \\"receiver\\": \\"\\u5916\\u58f3\\", \\"type\\": \\"\\u6709\\u5bb3\\", \\"verb\\": \\"\\u611f\\u77e5\\u70ed\\u91cf\\"}, {\\"tool\\": \\"\\u73af\\u5883\\u7a7a\\u6c14\\", \\"receiver\\": \\"\\u5916\\u58f3\\", \\"type\\": \\"\\u6b63\\u5e38\\", \\"verb\\": \\"\\u5e26\\u8d70\\u70ed\\u91cf\\"}, {\\"tool\\": \\"\\u5145\\u7535\\u5668\\", \\"receiver\\": \\"\\u7535\\u6c60\\", \\"type\\": \\"\\u6b63\\u5e38\\", \\"verb\\": \\"\\u8f93\\u5165\\u7535\\u6d41\\u53d1\\u70ed\\"}, {\\"tool\\": \\"\\u5e94\\u7528\\u7a0b\\u5e8f\\", \\"receiver\\": \\"CPU\\", \\"type\\": \\"\\u4e0d\\u8db3\\", \\"verb\\": \\"\\u589e\\u52a0\\u8d1f\\u8f7d\\"}]}, \\"root_cause_analysis\\": {\\"root_causes\\": [{\\"id\\": \\"rc1\\", \\"text\\": \\"\\u624b\\u673aCPU\\u6216GPU\\u957f\\u65f6\\u95f4\\u9ad8\\u8d1f\\u8f7d\\u8fd0\\u884c\\u5bfc\\u81f4\\u53d1\\u70ed\\"}, {\\"id\\": \\"rc2\\", \\"text\\": \\"\\u7535\\u6c60\\u8001\\u5316\\u6216\\u635f\\u574f\\u5bfc\\u81f4\\u5185\\u963b\\u589e\\u5927\\u53d1\\u70ed\\"}, {\\"id\\": \\"rc3\\", \\"text\\": \\"\\u5145\\u7535\\u65f6\\u4f7f\\u7528\\u624b\\u673a\\u6216\\u4f7f\\u7528\\u975e\\u539f\\u88c5\\u5145\\u7535\\u5668\\u5bfc\\u81f4\\u7535\\u6d41\\u4e0d\\u7a33\\u5b9a\\u53d1\\u70ed\\"}], \\"key_insights\\": [\\"\\u624b\\u673a\\u53d1\\u70ed\\u901a\\u5e38\\u7531\\u9ad8\\u8d1f\\u8f7d\\u8fd0\\u884c\\u3001\\u7535\\u6c60\\u95ee\\u9898\\u6216\\u5145\\u7535\\u4e0d\\u5f53\\u5f15\\u8d77\\"], \\"initial_defect\\": \\"\\u624b\\u673a\\u53d1\\u70ed\\"}, \\"trimming_analysis\\": {\\"trimming_candidates\\": [{\\"component\\": \\"\\u6563\\u70ed\\u6a21\\u5757\\", \\"reason\\": \\"\\u88ab\\u52a8\\u6563\\u70ed\\u53ef\\u7531\\u5916\\u58f3\\u548c\\u73af\\u5883\\u7a7a\\u6c14\\u5b8c\\u6210\\uff0c\\u4e3b\\u52a8\\u6563\\u70ed\\u975e\\u5fc5\\u9700\\", \\"transferred_to\\": \\"\\u5916\\u58f3, \\u73af\\u5883\\u7a7a\\u6c14\\"}, {\\"component\\": \\"\\u6e29\\u5ea6\\u4f20\\u611f\\u5668\\", \\"reason\\": \\"CPU\\u5185\\u90e8\\u53ef\\u6d4b\\u6e29\\uff0c\\u64cd\\u4f5c\\u7cfb\\u7edf\\u53ef\\u4f30\\u7b97\\u6e29\\u5ea6\\", \\"transferred_to\\": \\"CPU, \\u64cd\\u4f5c\\u7cfb\\u7edf/\\u8f6f\\u4ef6\\"}], \\"summary\\": \\"\\u901a\\u8fc7\\u88c1\\u526a\\u6563\\u70ed\\u6a21\\u5757\\u548c\\u6e29\\u5ea6\\u4f20\\u611f\\u5668\\uff0c\\u5206\\u522b\\u7531\\u5916\\u58f3\\u3001\\u73af\\u5883\\u7a7a\\u6c14\\u4ee5\\u53caCPU\\u3001\\u64cd\\u4f5c\\u7cfb\\u7edf\\u627f\\u62c5\\u529f\\u80fd\\uff0c\\u7b80\\u5316\\u7cfb\\u7edf\\u4f46\\u9700\\u9a8c\\u8bc1\\u662f\\u5426\\u6ee1\\u8db3\\u6563\\u70ed\\u548c\\u6d4b\\u6e29\\u9700\\u6c42\\u3002\\"}, \\"innovations\\": [{\\"id\\": \\"in1\\", \\"source_analyzer\\": \\"\\u8d44\\u6e90\\u5206\\u6790\\", \\"description\\": \\"\\u5229\\u7528\\u70ed\\u80fd\\u8d44\\u6e90\\u8fdb\\u884c\\u70ed\\u7535\\u8f6c\\u6362\\", \\"principle\\": \\"\\u80fd\\u91cf\\u8f6c\\u6362\\u539f\\u7406\\", \\"expected_effect\\": \\"\\u5c06\\u5e9f\\u70ed\\u8f6c\\u5316\\u4e3a\\u7535\\u80fd\\uff0c\\u964d\\u4f4e\\u8868\\u9762\\u6e29\\u5ea6\\u5e76\\u63d0\\u5347\\u80fd\\u6548\\", \\"user_rating\\": null}, {\\"id\\": \\"in2\\", \\"source_analyzer\\": \\"\\u8d44\\u6e90\\u5206\\u6790\\", \\"description\\": \\"\\u5229\\u7528\\u65f6\\u95f4\\u8d44\\u6e90\\u5b9e\\u73b0\\u95f4\\u6b47\\u6027\\u4e3b\\u52a8\\u6563\\u70ed\\", \\"principle\\": \\"\\u5468\\u671f\\u6027\\u4f5c\\u7528\\u539f\\u7406\\", \\"expected_effect\\": \\"\\u5728\\u975e\\u4f7f\\u7528\\u95f4\\u9699\\u8fdb\\u884c\\u9ad8\\u6548\\u6563\\u70ed\\uff0c\\u907f\\u514d\\u6301\\u7eed\\u9ad8\\u6e29\\", \\"user_rating\\": null}, {\\"id\\": \\"in3\\", \\"source_analyzer\\": \\"\\u7269-\\u573a\\u5206\\u6790\\", \\"description\\": \\"\\u5f15\\u5165\\u76f8\\u53d8\\u6750\\u6599\\u6291\\u5236\\u77ac\\u65f6\\u70ed\\u5cf0\\", \\"principle\\": \\"\\u76f8\\u53d8\\u539f\\u7406\\", \\"expected_effect\\": \\"\\u5229\\u7528\\u76f8\\u53d8\\u6f5c\\u70ed\\u5438\\u6536\\u5cf0\\u503c\\u70ed\\u6d41\\uff0c\\u5b9e\\u73b0\\u6052\\u6e29\\u7f13\\u51b2\\", \\"user_rating\\": null}, {\\"id\\": \\"in4\\", \\"source_analyzer\\": \\"\\u529f\\u80fd\\u5206\\u6790\\", \\"description\\": \\"\\u4f18\\u5316\\u70ed\\u4f20\\u5bfc\\u8def\\u5f84\\uff0c\\u589e\\u52a0\\u9ad8\\u70ed\\u5bfc\\u7387\\u6750\\u6599\\", \\"principle\\": \\"\\u5c40\\u90e8\\u8d28\\u91cf\\u539f\\u7406\\", \\"expected_effect\\": \\"\\u51cf\\u5c11\\u63a5\\u89e6\\u70ed\\u963b\\uff0c\\u5feb\\u901f\\u5c06\\u70ed\\u6e90\\u70ed\\u91cf\\u4f20\\u5bfc\\u81f3\\u66f4\\u5927\\u6563\\u70ed\\u9762\\u79ef\\", \\"user_rating\\": null}, {\\"id\\": \\"in5\\", \\"source_analyzer\\": \\"\\u56e0\\u679c\\u94fe\\u5206\\u6790\\", \\"description\\": \\"\\u52a8\\u6001\\u8c03\\u6574\\u8d1f\\u8f7d\\u5206\\u5e03\\u4ee5\\u5747\\u8861\\u4ea7\\u70ed\\", \\"principle\\": \\"\\u52a8\\u6001\\u6027\\u539f\\u7406\\", \\"expected_effect\\": \\"\\u901a\\u8fc7\\u4efb\\u52a1\\u8c03\\u5ea6\\u907f\\u514d\\u5c40\\u90e8\\u70ed\\u70b9\\uff0c\\u964d\\u4f4e\\u6574\\u4f53\\u6e29\\u5347\\u901f\\u7387\\", \\"user_rating\\": null}, {\\"id\\": \\"in6\\", \\"source_analyzer\\": \\"\\u88c1\\u526a\\u5206\\u6790\\", \\"description\\": \\"\\u589e\\u5f3a\\u5916\\u58f3\\u8868\\u9762\\u70ed\\u8f90\\u5c04\\u7279\\u6027\\", \\"principle\\": \\"\\u5229\\u7528\\u632f\\u52a8\\u539f\\u7406\\", \\"expected_effect\\": \\"\\u901a\\u8fc7\\u8f90\\u5c04\\u6d82\\u5c42\\u6216\\u7eb9\\u7406\\u8bbe\\u8ba1\\u63d0\\u9ad8\\u7ea2\\u5916\\u53d1\\u5c04\\u7387\\uff0c\\u589e\\u5f3a\\u88ab\\u52a8\\u6563\\u70ed\\", \\"user_rating\\": null}]}"}, {"agent_id": "agent5", "agent_type": "patent_search", "agent_label": "\\u4e13\\u5229\\u5206\\u6790Agent", "description": "\\u68c0\\u7d22\\u76f8\\u5173\\u4e13\\u5229\\uff0c\\u5206\\u6790\\u6280\\u672f\\u65b9\\u6848", "status": "pending", "started_at": null, "completed_at": null, "duration": null, "output": null}, {"agent_id": "agent3", "agent_type": "solution_gen", "agent_label": "\\u65b9\\u6848\\u751f\\u6210Agent", "description": "\\u751f\\u6210\\u521b\\u65b0\\u65b9\\u6848\\uff0c\\u6574\\u5408\\u591a\\u6e90\\u77e5\\u8bc6", "status": "pending", "started_at": null, "completed_at": null, "duration": null, "output": null}, {"agent_id": "agent4", "agent_type": "evaluation", "agent_label": "\\u65b9\\u6848\\u8bc4\\u4f30Agent", "description": "\\u8bc4\\u4f30\\u65b9\\u6848\\u53ef\\u884c\\u6027\\u4e0e\\u521b\\u65b0\\u6027", "status": "pending", "started_at": null, "completed_at": null, "duration": null, "output": null}, {"agent_id": "agent6", "agent_type": "evaluation", "agent_label": "\\u6210\\u679c\\u8f6c\\u5316Agent", "description": "\\u8f93\\u51fa\\u7ed3\\u6784\\u5316\\u6210\\u679c\\uff0c\\u652f\\u6301\\u8f6c\\u5316", "status": "pending", "started_at": null, "completed_at": null, "duration": null, "output": null}]	2026-07-04 00:49:24	2026-07-04 00:49:24
6	6	completed	[{"agentId": "agent1", "agentType": "problem_analysis", "agentLabel": "需求洞察", "status": "completed", "description": "需求洞察已完成", "duration": "2.3s"}, {"agentId": "agent2", "agentType": "problem_analysis", "agentLabel": "问题建模", "status": "completed", "description": "问题建模已完成", "duration": "2.3s"}, {"agentId": "agent5", "agentType": "problem_analysis", "agentLabel": "专利检索", "status": "completed", "description": "专利检索已完成", "duration": "2.3s"}, {"agentId": "agent3", "agentType": "problem_analysis", "agentLabel": "方案生成", "status": "completed", "description": "方案生成已完成", "duration": "2.3s"}, {"agentId": "agent4", "agentType": "problem_analysis", "agentLabel": "方案评估", "status": "completed", "description": "方案评估已完成", "duration": "2.3s"}, {"agentId": "agent6", "agentType": "problem_analysis", "agentLabel": "成果转化", "status": "completed", "description": "成果转化已完成", "duration": "2.3s"}]	2026-07-04 00:59:19	2026-07-04 00:59:19
7	7	completed	[{"agentId": "agent1", "agentType": "problem_analysis", "agentLabel": "需求洞察", "status": "completed", "description": "需求洞察已完成", "duration": "2.3s"}, {"agentId": "agent2", "agentType": "problem_analysis", "agentLabel": "问题建模", "status": "completed", "description": "问题建模已完成", "duration": "2.3s"}, {"agentId": "agent5", "agentType": "problem_analysis", "agentLabel": "专利检索", "status": "completed", "description": "专利检索已完成", "duration": "2.3s"}, {"agentId": "agent3", "agentType": "problem_analysis", "agentLabel": "方案生成", "status": "completed", "description": "方案生成已完成", "duration": "2.3s"}, {"agentId": "agent4", "agentType": "problem_analysis", "agentLabel": "方案评估", "status": "completed", "description": "方案评估已完成", "duration": "2.3s"}, {"agentId": "agent6", "agentType": "problem_analysis", "agentLabel": "成果转化", "status": "completed", "description": "成果转化已完成", "duration": "2.3s"}]	2026-07-04 00:59:19	2026-07-04 00:59:19
8	8	completed	[{"agentId": "agent1", "agentType": "problem_analysis", "agentLabel": "需求洞察", "status": "completed", "description": "需求洞察已完成", "duration": "2.3s"}, {"agentId": "agent2", "agentType": "problem_analysis", "agentLabel": "问题建模", "status": "completed", "description": "问题建模已完成", "duration": "2.3s"}, {"agentId": "agent5", "agentType": "problem_analysis", "agentLabel": "专利检索", "status": "completed", "description": "专利检索已完成", "duration": "2.3s"}, {"agentId": "agent3", "agentType": "problem_analysis", "agentLabel": "方案生成", "status": "completed", "description": "方案生成已完成", "duration": "2.3s"}, {"agentId": "agent4", "agentType": "problem_analysis", "agentLabel": "方案评估", "status": "completed", "description": "方案评估已完成", "duration": "2.3s"}, {"agentId": "agent6", "agentType": "problem_analysis", "agentLabel": "成果转化", "status": "completed", "description": "成果转化已完成", "duration": "2.3s"}]	2026-07-04 00:59:19	2026-07-04 00:59:19
9	9	completed	[{"agentId": "agent1", "agentType": "problem_analysis", "agentLabel": "需求洞察", "status": "completed", "description": "需求洞察已完成", "duration": "2.3s"}, {"agentId": "agent2", "agentType": "problem_analysis", "agentLabel": "问题建模", "status": "completed", "description": "问题建模已完成", "duration": "2.3s"}, {"agentId": "agent5", "agentType": "problem_analysis", "agentLabel": "专利检索", "status": "completed", "description": "专利检索已完成", "duration": "2.3s"}, {"agentId": "agent3", "agentType": "problem_analysis", "agentLabel": "方案生成", "status": "completed", "description": "方案生成已完成", "duration": "2.3s"}, {"agentId": "agent4", "agentType": "problem_analysis", "agentLabel": "方案评估", "status": "completed", "description": "方案评估已完成", "duration": "2.3s"}, {"agentId": "agent6", "agentType": "problem_analysis", "agentLabel": "成果转化", "status": "completed", "description": "成果转化已完成", "duration": "2.3s"}]	2026-07-04 00:59:19	2026-07-04 00:59:19
10	10	completed	[{"agentId": "agent1", "agentType": "problem_analysis", "agentLabel": "需求洞察", "status": "completed", "description": "需求洞察已完成", "duration": "2.3s"}, {"agentId": "agent2", "agentType": "problem_analysis", "agentLabel": "问题建模", "status": "completed", "description": "问题建模已完成", "duration": "2.3s"}, {"agentId": "agent5", "agentType": "problem_analysis", "agentLabel": "专利检索", "status": "completed", "description": "专利检索已完成", "duration": "2.3s"}, {"agentId": "agent3", "agentType": "problem_analysis", "agentLabel": "方案生成", "status": "completed", "description": "方案生成已完成", "duration": "2.3s"}, {"agentId": "agent4", "agentType": "problem_analysis", "agentLabel": "方案评估", "status": "completed", "description": "方案评估已完成", "duration": "2.3s"}, {"agentId": "agent6", "agentType": "problem_analysis", "agentLabel": "成果转化", "status": "completed", "description": "成果转化已完成", "duration": "2.3s"}]	2026-07-04 00:59:19	2026-07-04 00:59:19
11	11	completed	[{"agentId": "agent1", "agentType": "problem_analysis", "agentLabel": "需求洞察", "status": "completed", "description": "需求洞察已完成", "duration": "2.3s"}, {"agentId": "agent2", "agentType": "problem_analysis", "agentLabel": "问题建模", "status": "completed", "description": "问题建模已完成", "duration": "2.3s"}, {"agentId": "agent5", "agentType": "problem_analysis", "agentLabel": "专利检索", "status": "completed", "description": "专利检索已完成", "duration": "2.3s"}, {"agentId": "agent3", "agentType": "problem_analysis", "agentLabel": "方案生成", "status": "completed", "description": "方案生成已完成", "duration": "2.3s"}, {"agentId": "agent4", "agentType": "problem_analysis", "agentLabel": "方案评估", "status": "completed", "description": "方案评估已完成", "duration": "2.3s"}, {"agentId": "agent6", "agentType": "problem_analysis", "agentLabel": "成果转化", "status": "completed", "description": "成果转化已完成", "duration": "2.3s"}]	2026-07-04 00:59:19	2026-07-04 00:59:19
\.


--
-- Name: analyses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.analyses_id_seq', 1, false);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: evaluations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.evaluations_id_seq', 32, true);


--
-- Name: feedbacks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.feedbacks_id_seq', 1, false);


--
-- Name: knowledge_docs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.knowledge_docs_id_seq', 1, false);


--
-- Name: knowledge_vectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.knowledge_vectors_id_seq', 1, false);


--
-- Name: model_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.model_providers_id_seq', 2, true);


--
-- Name: models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.models_id_seq', 51, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: patents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.patents_id_seq', 33, true);


--
-- Name: problem_modelings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.problem_modelings_id_seq', 1, false);


--
-- Name: solutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.solutions_id_seq', 8, true);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 4, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.tasks_id_seq', 11, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: innovos
--

SELECT pg_catalog.setval('public.workflows_id_seq', 11, true);


--
-- Name: analyses analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_pkey PRIMARY KEY (id);


--
-- Name: analyses analyses_task_id_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_task_id_key UNIQUE (task_id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: evaluations evaluations_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_pkey PRIMARY KEY (id);


--
-- Name: feedbacks feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_pkey PRIMARY KEY (id);


--
-- Name: knowledge_bases knowledge_bases_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_bases
    ADD CONSTRAINT knowledge_bases_pkey PRIMARY KEY (id);


--
-- Name: knowledge_docs knowledge_docs_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_docs
    ADD CONSTRAINT knowledge_docs_pkey PRIMARY KEY (id);


--
-- Name: knowledge_groups knowledge_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_groups
    ADD CONSTRAINT knowledge_groups_pkey PRIMARY KEY (id);


--
-- Name: knowledge_items knowledge_items_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_items
    ADD CONSTRAINT knowledge_items_pkey PRIMARY KEY (id);


--
-- Name: knowledge_jobs knowledge_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_jobs
    ADD CONSTRAINT knowledge_jobs_pkey PRIMARY KEY (id);


--
-- Name: knowledge_vectors knowledge_vectors_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors
    ADD CONSTRAINT knowledge_vectors_pkey PRIMARY KEY (id);


--
-- Name: model_providers model_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.model_providers
    ADD CONSTRAINT model_providers_pkey PRIMARY KEY (id);


--
-- Name: model_providers model_providers_provider_id_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.model_providers
    ADD CONSTRAINT model_providers_provider_id_key UNIQUE (provider_id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: patent_vectors patent_vectors_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.patent_vectors
    ADD CONSTRAINT patent_vectors_pkey PRIMARY KEY (patent_id);


--
-- Name: patents patents_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.patents
    ADD CONSTRAINT patents_pkey PRIMARY KEY (id);


--
-- Name: problem_modelings problem_modelings_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.problem_modelings
    ADD CONSTRAINT problem_modelings_pkey PRIMARY KEY (id);


--
-- Name: problem_modelings problem_modelings_task_id_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.problem_modelings
    ADD CONSTRAINT problem_modelings_task_id_key UNIQUE (task_id);


--
-- Name: solutions solutions_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.solutions
    ADD CONSTRAINT solutions_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_key_key UNIQUE (key);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_task_id_key; Type: CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_task_id_key UNIQUE (task_id);


--
-- Name: idx_analyses_task_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_analyses_task_id ON public.analyses USING btree (task_id);


--
-- Name: idx_api_keys_is_active; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_api_keys_is_active ON public.api_keys USING btree (is_active);


--
-- Name: idx_audit_log_action; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_log_created; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_audit_log_created ON public.audit_log USING btree (created_at);


--
-- Name: idx_audit_log_user; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_audit_log_user ON public.audit_log USING btree (user_id);


--
-- Name: idx_evaluations_solution_user; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_evaluations_solution_user ON public.evaluations USING btree (solution_id, user_id);


--
-- Name: idx_feedbacks_solution_user; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_feedbacks_solution_user ON public.feedbacks USING btree (solution_id, user_id);


--
-- Name: idx_knowledge_bases_user_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_bases_user_id ON public.knowledge_bases USING btree (user_id);


--
-- Name: idx_knowledge_docs_user_active; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_docs_user_active ON public.knowledge_docs USING btree (user_id, is_active);


--
-- Name: idx_knowledge_groups_user_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_groups_user_id ON public.knowledge_groups USING btree (user_id);


--
-- Name: idx_knowledge_items_base_group_created; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_items_base_group_created ON public.knowledge_items USING btree (base_id, group_id, created_at);


--
-- Name: idx_knowledge_items_base_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_items_base_id ON public.knowledge_items USING btree (base_id);


--
-- Name: idx_knowledge_items_base_type_created; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_items_base_type_created ON public.knowledge_items USING btree (base_id, type, created_at);


--
-- Name: idx_knowledge_items_status; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_items_status ON public.knowledge_items USING btree (status);


--
-- Name: idx_knowledge_jobs_idempotency; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_jobs_idempotency ON public.knowledge_jobs USING btree (idempotency_key);


--
-- Name: idx_knowledge_jobs_idempotency_unique; Type: INDEX; Schema: public; Owner: innovos
--

CREATE UNIQUE INDEX idx_knowledge_jobs_idempotency_unique ON public.knowledge_jobs USING btree (idempotency_key) WHERE ((idempotency_key IS NOT NULL) AND (idempotency_key <> ''::text));


--
-- Name: idx_knowledge_jobs_queue_status; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_jobs_queue_status ON public.knowledge_jobs USING btree (queue, status);


--
-- Name: idx_knowledge_vectors_base_item; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_vectors_base_item ON public.knowledge_vectors USING btree (base_id, item_id);


--
-- Name: idx_knowledge_vectors_item_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_vectors_item_id ON public.knowledge_vectors USING btree (item_id);


--
-- Name: idx_knowledge_vectors_user_base; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_knowledge_vectors_user_base ON public.knowledge_vectors USING btree (user_id, base_id);


--
-- Name: idx_models_provider_model; Type: INDEX; Schema: public; Owner: innovos
--

CREATE UNIQUE INDEX idx_models_provider_model ON public.models USING btree (provider_id, model_id);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_patent_embedding_hnsw; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_patent_embedding_hnsw ON public.patent_vectors USING hnsw (embedding public.halfvec_cosine_ops) WITH (m='16', ef_construction='200');


--
-- Name: idx_patents_patent_number; Type: INDEX; Schema: public; Owner: innovos
--

CREATE UNIQUE INDEX idx_patents_patent_number ON public.patents USING btree (patent_number) WHERE (patent_number <> ''::text);


--
-- Name: idx_patents_relevance_score; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_patents_relevance_score ON public.patents USING btree (relevance_score DESC);


--
-- Name: idx_problem_modelings_task_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_problem_modelings_task_id ON public.problem_modelings USING btree (task_id);


--
-- Name: idx_solutions_task_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_solutions_task_id ON public.solutions USING btree (task_id);


--
-- Name: idx_tasks_user_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_tasks_user_id ON public.tasks USING btree (user_id);


--
-- Name: idx_workflows_task_id; Type: INDEX; Schema: public; Owner: innovos
--

CREATE INDEX idx_workflows_task_id ON public.workflows USING btree (task_id);


--
-- Name: analyses analyses_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.analyses
    ADD CONSTRAINT analyses_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: evaluations evaluations_solution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_solution_id_fkey FOREIGN KEY (solution_id) REFERENCES public.solutions(id) ON DELETE CASCADE;


--
-- Name: evaluations evaluations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.evaluations
    ADD CONSTRAINT evaluations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: feedbacks feedbacks_solution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_solution_id_fkey FOREIGN KEY (solution_id) REFERENCES public.solutions(id) ON DELETE CASCADE;


--
-- Name: feedbacks feedbacks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: knowledge_vectors fk_kv_base; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors
    ADD CONSTRAINT fk_kv_base FOREIGN KEY (base_id) REFERENCES public.knowledge_bases(id) ON DELETE CASCADE;


--
-- Name: knowledge_vectors fk_kv_item; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors
    ADD CONSTRAINT fk_kv_item FOREIGN KEY (item_id) REFERENCES public.knowledge_items(id) ON DELETE CASCADE;


--
-- Name: knowledge_bases knowledge_bases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_bases
    ADD CONSTRAINT knowledge_bases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: knowledge_docs knowledge_docs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_docs
    ADD CONSTRAINT knowledge_docs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: knowledge_groups knowledge_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_groups
    ADD CONSTRAINT knowledge_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: knowledge_items knowledge_items_base_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_items
    ADD CONSTRAINT knowledge_items_base_id_fkey FOREIGN KEY (base_id) REFERENCES public.knowledge_bases(id) ON DELETE CASCADE;


--
-- Name: knowledge_vectors knowledge_vectors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.knowledge_vectors
    ADD CONSTRAINT knowledge_vectors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: patent_vectors patent_vectors_patent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.patent_vectors
    ADD CONSTRAINT patent_vectors_patent_id_fkey FOREIGN KEY (patent_id) REFERENCES public.patents(id) ON DELETE CASCADE;


--
-- Name: problem_modelings problem_modelings_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.problem_modelings
    ADD CONSTRAINT problem_modelings_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: solutions solutions_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.solutions
    ADD CONSTRAINT solutions_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: workflows workflows_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: innovos
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict cZprGSR0dcISHqZoyAhcgn4eN0mqXmgRM5MaznTaR2Z5Vz1U951ZlPDFY2GMHUT

